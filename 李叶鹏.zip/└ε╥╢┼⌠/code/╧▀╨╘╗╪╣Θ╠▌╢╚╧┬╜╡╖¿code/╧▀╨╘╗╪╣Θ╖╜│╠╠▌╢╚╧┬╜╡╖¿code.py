{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "da0ac6b5-9d83-48ed-aa46-eef386a5390e",
   "metadata": {},
   "outputs": [],
   "source": [
    "#导入numpy、pandas、matplotlib库\n",
    "#设置图表风格\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "%matplotlib inline\n",
    "plt.style.use('seaborn-whitegrid')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "58b1d579-8f27-4e8d-b2e1-d2d725a1f685",
   "metadata": {},
   "outputs": [],
   "source": [
    "#写入数据\n",
    "train_ = pd.read_csv(r\"train_.csv\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "aecc4a9a-d8df-4c7b-a837-cded2a8ff34f",
   "metadata": {},
   "outputs": [],
   "source": [
    "#对每一列中的缺失值，用中位数填充\n",
    "train_[\"0\"].fillna(train_[\"0\"].median(),inplace=True)\n",
    "train_[\"1\"].fillna(train_[\"1\"].median(),inplace=True)\n",
    "train_[\"2\"].fillna(train_[\"2\"].median(),inplace=True)\n",
    "train_[\"3\"].fillna(train_[\"3\"].median(),inplace=True)\n",
    "train_[\"4\"].fillna(train_[\"4\"].median(),inplace=True)\n",
    "train_[\"5\"].fillna(train_[\"5\"].median(),inplace=True)\n",
    "train_[\"6\"].fillna(train_[\"6\"].median(),inplace=True)\n",
    "train_[\"7\"].fillna(train_[\"7\"].median(),inplace=True)\n",
    "train_[\"8\"].fillna(train_[\"8\"].median(),inplace=True)\n",
    "train_[\"9\"].fillna(train_[\"9\"].median(),inplace=True)\n",
    "train_[\"10\"].fillna(train_[\"10\"].median(),inplace=True)\n",
    "train_[\"11\"].fillna(train_[\"11\"].median(),inplace=True)\n",
    "train_[\"12\"].fillna(train_[\"12\"].median(),inplace=True)\n",
    "train_[\"outcome\"].fillna(train_[\"outcome\"].median(),inplace=True)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "a9f30f84-aa24-4ffc-9d91-4db108158725",
   "metadata": {},
   "outputs": [],
   "source": [
    "#将输入数据由df转化成数组\n",
    "train_ = np.array(train_)\n",
    "\n",
    "'''数据归一化之前，对不需要归一化的y值先进行分割，\n",
    "404个样本数据取前400个，平均分成5组，每组80个样本，分组是为了后面的交叉验证。\n",
    "其中四组作为训练集，剩余一组做验证集。'''\n",
    "train_y = train_[:,-1:]\n",
    "#train_y1到train_y5是训练集，每组320个样本。\n",
    "train_y1 = train_[0:320,-1:]    \n",
    "train_y2 = train_[80:400,-1:]\n",
    "\n",
    "#将后240个样本与前80个样本y值按照0轴方向拼接。\n",
    "a = train_[160:400,-1:]         \n",
    "b = train_[0:80,-1:]\n",
    "train_y3 = np.concatenate([a, b], axis=0)\n",
    "\n",
    "#将后160个样本与前160个样本y值按照0轴方向拼接。\n",
    "c = train_[240:400,-1:]         \n",
    "d = train_[0:160,-1:]\n",
    "train_y4 = np.concatenate([c, d], axis=0)\n",
    "\n",
    "#将后80个样本与前240个样本y值按照0轴方向拼接。\n",
    "e = train_[320:400,-1:]         \n",
    "f = train_[0:240,-1:]         \n",
    "train_y5 = np.concatenate([e, f], axis=0)\n",
    "\n",
    "#train_y6到train_y10是验证集，每组80个样本。\n",
    "train_y6 = train_[0:80,-1:]  \n",
    "train_y7 = train_[80:160,-1:]\n",
    "train_y8 = train_[160:240,-1:]\n",
    "train_y9 = train_[240:320,-1:]\n",
    "train_y10 = train_[320:400,-1:]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "c45eae15-f006-4fa9-a18a-374c69be80e4",
   "metadata": {},
   "outputs": [],
   "source": [
    "#计算每一列数据的平均值\n",
    "train_average = np.average(train_,axis = 0)\n",
    "\n",
    "#计算每一列的标准差\n",
    "train_sigma = np.std(train_,axis = 0)\n",
    "\n",
    "#利用广播机制使数据均值为0，标准差为1\n",
    "train_ = (train_ - train_average) / train_sigma "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "de54a251-e4d7-4ab9-a958-d7a7758fc3df",
   "metadata": {},
   "outputs": [],
   "source": [
    "'''和 y值分割方法一致，取前400个样本，平均分成5组，\n",
    "其中四组作为训练集，剩余一组做验证集。'''\n",
    "train_x = train_[:,1:14]\n",
    "\n",
    "#train_x1到train_x5是训练集。\n",
    "train_x1 = train_[0:320,1:14]                                   \n",
    "train_x2 = train_[80:400,1:14]\n",
    "\n",
    "#将后240个样本与前80个样本x值按照垂直方向拼接。\n",
    "a = train_[160:400,1:14]\n",
    "b = train_[0:80,1:14]\n",
    "train_x3 = np.vstack([a,b]) \n",
    "\n",
    "#将后160个样本与前160个样本x值按照垂直方向拼接。\n",
    "c = train_[240:400,1:14]\n",
    "d = train_[0:160,1:14]\n",
    "train_x4 = np.vstack([c,d])\n",
    "\n",
    "#将后80个样本与前240个样本y值按照垂直方向拼接。\n",
    "e = train_[320:400,1:14]\n",
    "f = train_[0:240,1:14]\n",
    "train_x5 = np.vstack([e,f])  \n",
    "  \n",
    "#train_x6到train_x10是验证集，每组80个样本。\n",
    "train_x6 = train_[0:80,1:14]\n",
    "train_x7 = train_[80:160,1:14]\n",
    "train_x8 = train_[160:240,1:14]\n",
    "train_x9 = train_[240:320,1:14]\n",
    "train_x10 = train_[320:400,1:14]\n",
    "\n",
    "#给每一个train_x集左边加上一列全1列，是为了后面与theta矩阵相乘多出一个偏移项。\n",
    "train_x = np.hstack([np.ones((404,1)),train_x])\n",
    "train_x1 = np.hstack([np.ones((320,1)),train_x1])               \n",
    "train_x2 = np.hstack([np.ones((320,1)),train_x2])              \n",
    "train_x3 = np.hstack([np.ones((320,1)),train_x3])\n",
    "train_x4 = np.hstack([np.ones((320,1)),train_x4])\n",
    "train_x5 = np.hstack([np.ones((320,1)),train_x5])\n",
    "train_x6 = np.hstack([np.ones((80,1)),train_x6])\n",
    "train_x7 = np.hstack([np.ones((80,1)),train_x7])\n",
    "train_x8 = np.hstack([np.ones((80,1)),train_x8])\n",
    "train_x9 = np.hstack([np.ones((80,1)),train_x9])\n",
    "train_x10 = np.hstack([np.ones((80,1)),train_x10])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "a03ca953-a2b4-4181-bf91-e04cd55b77c1",
   "metadata": {},
   "outputs": [],
   "source": [
    "#在梯度下降中加入一个惩罚项，防止过拟合。\n",
    "#每迭代一次a加一，直到迭代次数达到设置的n，既a=n时迭代停止。\n",
    "def gradient_descent_ridge(X,y,theta,eta,n,lamda):\n",
    "    a = 0\n",
    "    while a<n:\n",
    "        dj = eta*np.dot(X.T,np.dot(X,theta)-y)/ len(X)\n",
    "        theta = theta - dj - 2*lamda*theta\n",
    "        a = a+1\n",
    "    return theta"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "49a57d56-4773-42e8-a29b-784fe91db9d4",
   "metadata": {},
   "outputs": [],
   "source": [
    "# X0 训练x集  y0 训练y集  X1 验证x集  y1 验证y集\n",
    "def mse(X0,y0,X1,y1):\n",
    "    theta = np.zeros((14,1))\n",
    "    eta = 0.035\n",
    "    n = 1e4\n",
    "    lamda = 0.0001\n",
    "    #用训练集训练出theta系数矩阵\n",
    "    theta = gradient_descent_ridge(X0,y0,theta,eta,n,lamda)\n",
    "    #计算预测值\n",
    "    y_hat = np.dot(X1,theta)\n",
    "    #用验证集计算系数矩阵对应的均方误差（ MSE）\n",
    "    mse_ = np.sum((y_hat - y1) ** 2) / len(X1)\n",
    "    mse_ = np.array(mse_)\n",
    "    return mse_"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "e284c4e9-0d04-410b-acae-6d49150044f1",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "#通过打印average_mse来确定eta lamda等值。\n",
    "average_mse = (mse(train_x2,train_y2,train_x6,train_y6) + mse(train_x3,train_y3,train_x7,train_y7) + mse(train_x4,train_y4,train_x8,train_y8) + mse(train_x5,train_y5,train_x9,train_y9) + mse(train_x1,train_y1,train_x10,train_y10)) / 5"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "f06601e7-c577-4735-8b6a-d60f20feb0ee",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "#通过打印average_mse,发现eta = 0.035，lamda = 0.0001可以使交叉熵函数尽可能的小。\n",
    "theta = np.zeros((14,1))\n",
    "eta = 0.035\n",
    "n = 1e4\n",
    "lamda = 0.0001\n",
    "result_theta = gradient_descent_ridge(train_x,train_y,theta,eta,n,lamda)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "id": "e707185b-ca87-415a-bd3b-362847fa3e72",
   "metadata": {},
   "outputs": [],
   "source": [
    "#数据的导入\n",
    "test_ = pd.read_csv(r\"test_.csv\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "1f6d9612-ee6a-4961-867c-72735e1baf5f",
   "metadata": {},
   "outputs": [],
   "source": [
    "#数据预处理————缺失值的处理\n",
    "#将缺失值用中位数代替\n",
    "test_[\"0\"].fillna(test_[\"0\"].median(),inplace=True)\n",
    "test_[\"12\"].fillna(test_[\"12\"].median(),inplace=True)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 13,
   "id": "22d5b71c-28cb-43d8-97a5-a132837c4119",
   "metadata": {},
   "outputs": [],
   "source": [
    "#数据预处理————Z-score标准化\n",
    "#利用广播机制使数据均值为0，标准差为1\n",
    "test_ = np.array(test_)\n",
    "test_average = np.average(test_,axis = 0)\n",
    "test_sigma = np.std(test_,axis = 0)\n",
    "test_ = (test_ - test_average) /test_sigma"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "637b66a5-c6e8-4240-aeec-0aea3839df17",
   "metadata": {},
   "outputs": [],
   "source": [
    "#数据预处理————归一化后的x训练集的分割\n",
    "test_x = test_[::,1:]\n",
    "test_x = np.hstack([np.ones((102,1)),test_x])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 15,
   "id": "948aad04-a616-4465-8772-55ab564d0789",
   "metadata": {},
   "outputs": [],
   "source": [
    "#得出最终结果\n",
    "predict_test_y = np.dot(test_x,result_theta)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "id": "e6f88934-4e28-462c-a3fb-72faebcc08cb",
   "metadata": {},
   "outputs": [],
   "source": [
    "#在结果的左侧添加0-102，作为id列。\n",
    "#将预测的y数据转换成df格式，添加表头，导出结果。\n",
    "predict_test_y = np.hstack([np.arange(0,102).reshape(102,1),predict_test_y])\n",
    "predict_test_y = pd.DataFrame(predict_test_y, columns=['id', 'outcome'])\n",
    "predict_test_y.to_csv('result_test.csv')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 17,
   "id": "989efd07-a9c2-4200-9fad-ffbd0342b361",
   "metadata": {},
   "outputs": [],
   "source": [
    "#将每一次迭代出的系数矩阵与测试集相乘，得出预测的y值，之后计算对应的均方误差。\n",
    "def mse1(X,y,theta,eta,n,lamda):\n",
    "    a = 0\n",
    "    mse_y = []\n",
    "    while a<n:\n",
    "        dj = eta*np.dot(X.T,np.dot(X,theta)-y)/len(X)\n",
    "        theta = theta - dj - 2*lamda*theta\n",
    "        y_hat = np.dot(X,theta)\n",
    "        mse_ = np.sum((y_hat - y) ** 2) / len(X)\n",
    "        #将每一次计算出的均方误差加入到列表mse_y中，将列表作为散点图的y值。\n",
    "        mse_y.append(mse_)\n",
    "        a = a+1\n",
    "    return mse_y"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "id": "36bf2351-72f9-4e72-bcad-90ebc1c10b72",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "theta = np.zeros((14,1))\n",
    "eta = 0.035\n",
    "n = 1e4\n",
    "lamda = 0.0001\n",
    "mse_y = mse1(train_x,train_y,theta,eta,n,lamda)\n",
    "#将得出的列表mse_y以90的步长切片，得出100个元素列表。\n",
    "mse_y = mse_y[1000:10000:90]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 19,
   "id": "94436763-0a4c-4f39-b0fd-a90efb758017",
   "metadata": {
    "tags": []
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "Text(0, 0.5, 'MSE y')"
      ]
     },
     "execution_count": 19,
     "metadata": {},
     "output_type": "execute_result"
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAkUAAAG8CAYAAADQC9GNAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMiwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy8qNh9FAAAACXBIWXMAAA9hAAAPYQGoP6dpAABHJElEQVR4nO3de1xVdb7/8fd2cxG80ziGwAyZeccBY0QzGqU0x2xKIunmIB1xRsi8HMLxMjlTk+MUKmiPUY/aqMl0ThGOl0TjpE500ZEGzJw4lsYRgckxAUNUYLN/f/hjn0g00L3X2sDr+Xj0mNlrrb32Z3+MePtd3/VdFrvdbhcAAEA718HsAgAAANwBoQgAAECEIgAAAEmEIgAAAEmEIgAAAEmEIgAAAEmEIgAAAEmEIgAAAEmEIgAAAEmSh9kFAMCNmjJliv72t78pLCxM//mf/9nkMXPmzNGuXbs0adIkLV26VJL00Ucfad26dcrPz9f58+f1ve99TyNHjtSMGTP0gx/8wPHeX/3qV9q6detVP7979+46ePCgc78UAMMRigC0CRaLRQUFBSorK5O/v3+jfRcuXND+/fsbbfvwww81bdo03X333frd736nrl276uTJk3rllVf08MMP64033mgUjHr27KmXX365yc/28OA/pUBbwE8ygDZh8ODB+vzzz7V7927Fx8c32rd37155e3urS5cujm1r1qxRSEiIVq5c6dgWERGhn/zkJxo7dqz+9Kc/afHixY59Xl5eCg0Ndfn3AGAe5hQBaBN8fX31k5/8RNnZ2Vfs27Vrl8aPH99oROfMmTNNnuf73/++Fi1apFGjRrmsVgDuiVAEoM2YMGGCDh8+rNLSUse2qqoqvfvuu5o4cWKjY0ePHq38/HxNmTJFmZmZKi4udux7+OGHdc8991xx/rq6uib/sdvtrvtSAAzD5TMAbcbo0aPl6+ur3bt368knn5Qk5eTkyM/PT7fffnujY2fNmqWvv/5ab775pv72t79Jknr16qXRo0crLi5Ot956a6PjS0pKNHjw4CY/d9asWUpMTHTBNwJgJEIRgDajY8eOioqKUnZ2tiMUvfXWW5owYYIsFkujY728vPTcc89p5syZ+utf/6oDBw7o4MGD+q//+i9lZWVp2bJluvfeex3H9+zZU6tXr27yc3v16uW6LwXAMIQiAG3KT3/6UyUlJenUqVPq1KmTPvzwQ82ePfuqx/fs2VMxMTGKiYmRJB08eFDJycn67W9/q7Fjx6pDh8uzDLy8vBQSEmLEVwBgEuYUAWhT7rrrLnXp0kV79uxRTk6OAgMDNWTIkEbHHD58WHfccYfef//9K94fERGhf/u3f9NXX32l8vJyo8oG4AYYKQLQpnh5eenuu+/W22+/LV9fX913331XHBMcHKwLFy5o8+bNGjlypGM0qMEXX3yhnj17ys/Pz6iyAbgBQhGANmfChAn6xS9+oQ4dOmjRokVX7O/WrZvmzZunxYsX67HHHtPkyZMVFBSkr7/+Wjk5Odq6datSU1MbzUOqqalRQUHBVT+zX79+8vX1dcXXAWAQQhGANueOO+5Q165d5e/vf8VdZA0eeeQR/fCHP9TmzZu1fPlyVVRUqFOnTho6dKg2bdqkiIiIRsf/61//Umxs7FU/MzMzkzlHQCtnsbPABgAAABOtAQAAJEIRAACAJEIRAACAJEIRAACAJEIRAACAJEIRAACAJNYpara6ujpVVlbK29v7itVvAQCAe6qvr9elS5fUrVs3eXhcO/YQipqpsrJSRUVFZpcBAACuQ3BwsG666aZrHkMoaiZvb29Jl5vq4+Pj1HPbbDYdO3ZM/fr1k9Vqdeq50Ri9Ng69Ng69Ng69No6zen3hwgUVFRU5fo9fC6GomRoumfn4+Dj9+UY2m02S5Ovryw+Zi9Fr49Br49Br49Br4zi7182Z+mLK5JjCwkLFx8dr+PDhGjVqlFJSUnT27FlJUkZGhsaNG6ewsDCNGzdOW7Zsuep5KisrlZycrIiICA0bNkxxcXH69NNPHfuLi4uVkJCg4cOHa+TIkUpJSdG5c+cc+z/44ANFR0dr2LBhGjNmjF5++WXx1BMAANonw0PRxYsXNW3aNIWFhem9997Tzp07VVFRoQULFmjv3r1KT0/X8uXLlZ+fr9TUVL344os6cOBAk+datGiRqqqqlJOTo4MHD2ro0KFKTEx07J87d6769u2r999/X9nZ2SotLdXSpUslSeXl5UpMTFRiYqL+/ve/a/369crIyNC2bdsM6QMAAHAvhl8+Ky0t1YABA5SUlCSr1SovLy/FxsYqJSVFa9as0d69e9W5c2fV1dWpvLxcFotFXbt2bfJcy5cvV319vby9vVVZWalz586pR48ejv3Hjx/X7bffLrvdLrvdLovF4pgPVFpaqgsXLqi+vt4xOvTN/QAAoH0xPBT16dNH69evb7Rtz549Gjx4sCSpc+fOOnHihCZOnCibzab4+HgNGjSoyXN5enpKklasWKG1a9eqU6dOWrt2rWP/zJkztWzZMm3evFk2m02hoaFKTk6WJA0aNEjjx4/XzJkzZbVaZbPZNGXKFN17772u+NoAAMDNmTrR2m63Ky0tTfv27Ws0dygoKEiHDx9WYWGhEhMT5efnp+nTp1/1PDNmzFBSUpIyMjKUkJCg7du3KygoSBaLRTNmzFB8fLzKy8s1d+5cPfvss3rppZdUU1Oj7t27Kz09XXfffbeOHDmipKQk9e/fXw8//PBVP8tmszkmfzlLw/mcfV5ciV4bh14bh14bh14bx1m9bsn7LXaTZhZXVVVp/vz5Onr0qFavXq3+/fs3edy6deu0Y8cObd++vVnnnTBhgiZPnqzw8HBNmTJFhw4dcizW9NFHH+nxxx9XXl6eXn/9db3//vvasGGD472rV69WTk6OsrKyrjhvdXV1o0ncAACg9Rg4cOB33j1uykjRyZMnlZCQoN69eyszM1N+fn6SpI0bN6qgoEBpaWmOY2tqatStW7cmz/PII49o6tSpGj9+/BXHl5WVyWazqb6+3rHP09NTFotFVqtVpaWlqqmpaXQ+Dw8PxyW5q+nXr59Lbsk/cuSIQkJCuMXTxei1cei1cei1cei1cZzV6+rqah07dqxZxxoeiiorKxUXF6cRI0bohRdeaLRuQHh4uFJTU7Vr1y6NHz9e+fn52rx5sxYvXtzkuYYOHapVq1YpJCREPXv21Jo1a1RTU6OoqCjZbDb5+PhoyZIlmj9/vqqqqrRs2TKNHTtWPj4+ioqK0p///Gdt3bpVDz74oP7nf/5Hr776qn7xi19cs36r1eqyHwRXnhuN0Wvj0Gvj0Gvj0Gvj3GivW/Jew0NRVlaWSktLlZ2drd27dzfal5+fr5UrVyotLU2LFi1SQECAFi5cqAkTJkiS8vLylJCQoLfeeku9e/dWcnKyrFarYmNjVVtbq9DQUG3atMkxsrRhwwalpqYqMjJS3t7eioqK0jPPPCNJuuOOO5Samqo1a9bo+eef1/e+9z09+eSTeuyxx4xtCAAAcAumzSlqbRrmFDXnmmRL2Gw27d+/XwcOHNCIESM0evRo/vbhQjabTQUFBQoNDaXPLkavjUOvjUOvjeOsXrfk9zeP+TBRVlaWZs2apVOnTjm2BQYGKj09XdHR0SZWBgBA+2PKYz5wORDFxMQ0CkSSVFJSopiYmCbvgAMAAK5DKDKBzWbTrFmzmnzOWsO22bNnsw4GAAAGIhSZIDc394oRom+y2+0qLi5Wbm6ugVUBANC+EYpMUFZW5tTjAADAjSMUmcDf39+pxwEAgBtHKDJBZGSkAgMDZbFYmtxvsVgUFBSkyMhIgysDAKD9IhSZwGq1Kj09vcl9DUEpLS2NNTAAADAQocgk0dHRyszM1Pe///1G2wMDA5WZmck6RQAAGIzFG00UHR2tvn376kc/+pF8fHy0Y8cOVrQGAMAkjBSZrHv37pKkuro6AhEAACYiFJmsS5cukqTa2lrV1NSYXA0AAO0XochkDaFIkr7++msTKwEAoH0jFJnMw8NDHTt2lEQoAgDATIQiN9AwWkQoAgDAPIQiN9AQis6dO2dyJQAAtF+EIjfASBEAAOYjFLmBzp07S5KqqqpMrgQAgPaLUOQGGCkCAMB8hCI30LVrV0mEIgAAzEQocgOMFAEAYD5CkRtomFNEKAIAwDyEIjfQMFLERGsAAMxDKHIDXD4DAMB8hCI3QCgCAMB8hCI3QCgCAMB8hCI3wERrAADMRyhyA0y0BgDAfIQiN8DlMwAAzEcocgOEIgAAzEcocgPfvHxmt9tNrgYAgPaJUOQGGkJRfX29qqurTa4GAID2iVDkBjp16iSLxSKJS2gAAJiFUOQGLBaLfH19JRGKAAAwC6HITRCKAAAwF6HITRCKAAAwF6HITXTq1EmSdO7cOZMrAQCgfSIUuYmGUMRIEQAA5iAUuQkunwEAYC5CkZsgFAEAYC5CkZvg8hkAAOYiFLkJRooAADAXochNEIoAADAXochNcPkMAABzEYrcBCNFAACYi1DkJhgpAgDAXIQiN8FIEQAA5iIUuQlCEQAA5iIUuQkunwEAYC5CkZtgpAgAAHMRitxEw0jRhQsXVFdXZ3I1AAC0P4QiN9EwUiRJVVVVJlYCAED7RChyE15eXvL09JTEJTQAAMxAKHIjXbp0kUQoAgDADKaEosLCQsXHx2v48OEaNWqUUlJSdPbsWUlSRkaGxo0bp7CwMI0bN05btmy56nkqKyuVnJysiIgIDRs2THFxcfr0008d+4uLi5WQkKDhw4dr5MiRSklJ0blz5xz7S0pKlJiYqPDwcEVERGjevHk6f/686774dyAUAQBgHsND0cWLFzVt2jSFhYXpvffe086dO1VRUaEFCxZo7969Sk9P1/Lly5Wfn6/U1FS9+OKLOnDgQJPnWrRokaqqqpSTk6ODBw9q6NChSkxMdOyfO3eu+vbtq/fff1/Z2dkqLS3V0qVLJUk1NTV68skndfPNNys3N1fZ2dn63//9Xy1btsyQPjSFUAQAgHk8jP7A0tJSDRgwQElJSbJarfLy8lJsbKxSUlK0Zs0a7d27V507d1ZdXZ3Ky8tlsVjUtWvXJs+1fPly1dfXy9vbW5WVlTp37px69Ojh2H/8+HHdfvvtstvtstvtslgs8vHxkSTt27dPNTU1WrhwoaxWq3x8fLRy5UpVV1cb0oemEIoAADCP4aGoT58+Wr9+faNte/bs0eDBgyVJnTt31okTJzRx4kTZbDbFx8dr0KBBTZ6rYWLyihUrtHbtWnXq1Elr16517J85c6aWLVumzZs3y2azKTQ0VMnJyZKkjz/+WAMGDFB6erq2b98uSbr33ns1Z84cp3/n5moIRd+8xAcAAIxheCj6JrvdrrS0NO3bt6/R3KGgoCAdPnxYhYWFSkxMlJ+fn6ZPn37V88yYMUNJSUnKyMhQQkKCtm/frqCgIFksFs2YMUPx8fEqLy/X3Llz9eyzz+qll15SZWWl3n33XQ0ZMkR79uzR6dOnNXPmTL344ot69tlnr/pZNptNNpvNqX1oOF/nzp0lXZ4r5ezPwGUNfaW/rkevjUOvjUOvjeOsXrfk/Ra73W6/oU+7TlVVVZo/f76OHj2q1atXq3///k0et27dOu3YscMxmvNdJkyYoMmTJys8PFxTpkzRoUOH5OFxOft99NFHevzxx5WXl6fly5frnXfe0V//+lfHe7Ozs/Xcc8/pww8/vOK81dXVjSZxu8Jvf/tb7dixQ0lJSYqPj3fpZwEA0J4MHDiw0ZqATTFlpOjkyZNKSEhQ7969lZmZKT8/P0nSxo0bVVBQoLS0NMexNTU16tatW5PneeSRRzR16lSNHz/+iuPLyspks9lUX1/v2Ofp6SmLxSKr1apbb71Vu3fvVn19vTp0uDzfvL6+Xt+VEfv16/edTW0pm82mI0eO6Ac/+IGkyyNGoaGhTv0MXNbQ65CQEFmtVrPLadPotXHotXHotXGc1evq6modO3asWccaHooqKysVFxenESNG6IUXXnAEEkkKDw9Xamqqdu3apfHjxys/P1+bN2/W4sWLmzzX0KFDtWrVKoWEhKhnz55as2aNampqFBUVJZvNJh8fHy1ZskTz589XVVWVli1bprFjx8rHx0c//elPtXLlSi1ZskQpKSk6ffq01qxZowceeOCa9VutVpf9IDRMKD9//jw/bC7myj9HNEavjUOvjUOvjXOjvW7Jew0PRVlZWSotLVV2drZ2797daF9+fr5WrlyptLQ0LVq0SAEBAVq4cKEmTJggScrLy1NCQoLeeust9e7dW8nJybJarYqNjVVtba1CQ0O1adMmx8jShg0blJqaqsjISHl7eysqKkrPPPOMJMnPz0+vvfaafv/73+uuu+6SJP3sZz/Tv//7vxvYjca4+wwAAPMYHori4+OvOV8mKipKUVFRTe4LDw9Xfn6+47WXl5fmzZunefPmNXn8kCFDtHHjxqt+Vp8+fbRu3brmFW4AQhEAAObhMR9uhFAEAIB5CEVuhFAEAIB5CEVupGGdIkIRAADGIxS5EUaKAAAwD6HIjRCKAAAwD6HIjXwzFJm00DgAAO0WociNNISiuro6Xbp0yeRqAABoXwhFbqRhorXEJTQAAIxGKHIjVqvV8Vw1QhEAAMYiFLkZJlsDAGAOQpGbaXgoLKEIAABjEYrcDCNFAACYg1DkZghFAACYg1DkZghFAACYg1DkZghFAACYg1DkZhpC0blz50yuBACA9oVQ5GYYKQIAwByEIjdDKAIAwByEIjdDKAIAwByEIjdDKAIAwByEIjdDKAIAwByEIjdDKAIAwByEIjdDKAIAwByEIjdDKAIAwByEIjfj6+srSTp79qz2798vm81mckUAALQPhCI3snXrVo0ZM0aSdOnSJY0ZM0bBwcHKysoyuTIAANo+QpGb2Lt3ryZPnqyysrJG20tKShQTE0MwAgDAxQhFbsBmsyk1NVV2u/2KfQ3bZs+ezaU0AABciFDkBnJzc3X69Omr7rfb7SouLlZubq6BVQEA0L4QitzAP//5z2Yd9+1LawAAwHkIRW7g5ptvbtZx/v7+Lq4EAID2i1DkBiIjI/X9739fFoulyf0Wi0VBQUGKjIw0uDIAANoPQpEbsFqtSk5OlqQrglHD67S0NFmtVsNrAwCgvSAUuYmoqCi9/vrrCggIaLQ9MDBQmZmZio6ONqkyAADaB0KRG5k0aZKKior0xBNPOF5/8cUXBCIAAAxAKHIzVqtVYWFhkiQfHx8umQEAYBBCkRvy8/OTdPn5ZwAAwBiEIjd00003SZK++uorkysBAKD9IBS5IUaKAAAwHqHIDTWMFBGKAAAwDqHIDTWMFFVUVPAQWAAADEIockM9evSQdPlBsBUVFeYWAwBAO0EockOenp7q2rWrJC6hAQBgFEKRm2q4hMYdaAAAGINQ5KaYbA0AgLEIRW6KkSIAAIxFKHJTrFUEAICxCEVuistnAAAYi1Dkprh8BgCAsQhFborLZwAAGItQ5KZ4KCwAAMYiFLkpRooAADAWochNMdEaAABjEYrcFBOtAQAwlimhqLCwUPHx8Ro+fLhGjRqllJQUx4hIRkaGxo0bp7CwMI0bN05btmy56nkqKyuVnJysiIgIDRs2THFxcfr0008d+4uLi5WQkKDhw4dr5MiRSklJ0blz5644T3V1tX76059q1apVzv+y16khFFVWVqqurs7kagAAaPsMD0UXL17UtGnTFBYWpvfee087d+5URUWFFixYoL179yo9PV3Lly9Xfn6+UlNT9eKLL+rAgQNNnmvRokWqqqpSTk6ODh48qKFDhyoxMdGxf+7cuerbt6/ef/99ZWdnq7S0VEuXLr3iPL/97W9VVFTkqq98XXr06OH4/xUVFeYVAgBAO2F4KCotLdWAAQOUlJQkLy8v9ejRQ7GxsTp06JCioqK0d+9eDRkyRHV1dSovL5fFYnE8Mf7bli9frvT0dHXt2lXV1dU6d+5cozBx/Phx2e12xz8Wi0U+Pj6NzpGVlaXS0lINGzbMpd+7pTw8PNStWzdJXEIDAMAIhoeiPn36aP369bJarY5te/bs0eDBgyVJnTt31okTJzR06FBNnz5djz76qAYNGtTkuTw9PeXt7a0VK1YoIiJCO3fu1IIFCxz7Z86cqS1btig0NFQjRoxQTU2NkpOTHfuPHz+uVatWKTU1VR06uN/0KiZbAwBgHA8zP9xutystLU379u1rNHcoKChIhw8fVmFhoRITE+Xn56fp06df9TwzZsxQUlKSMjIylJCQoO3btysoKEgWi0UzZsxQfHy8ysvLNXfuXD377LN66aWXdPHiRc2ePVuLFi1Sr169ml2zzWaTzWa7oe/d1Dm/+b8N/Pz8dOLECZ0+fdrpn9leXa3XcD56bRx6bRx6bRxn9bol7zctFFVVVWn+/Pk6evSotmzZov79+zv2eXp6SpJCQkL085//XDt27LhmKOrYsaMkKT4+Xm+88YbeeecdhYeHKz09XYcOHZKHh4d8fX2VkpKixx9/XIsXL9bSpUsVERGhu+++u0V1Hzt27Dq+bfMcOXKk0WsPj8t/PAUFBQoMDHTZ57ZH3+41XIdeG4deG4deG8fIXpsSik6ePKmEhAT17t1bmZmZjjutNm7cqIKCAqWlpTmOrampccyt+bZHHnlEU6dO1fjx4684vqysTDabTfX19Y59np6eslgsslqt2r59uzw9PfWXv/xF0uU70AoKCvT2229rx44dV629X79+8vX1vYFvfyWbzaYjR44oJCSk0WXF4OBgHThwQF26dFFoaKhTP7O9ulqv4Xz02jj02jj02jjO6nV1dXWzBzQMD0WVlZWKi4vTiBEj9MILLzSayxMeHq7U1FTt2rVL48ePV35+vjZv3qzFixc3ea6hQ4dq1apVCgkJUc+ePbVmzRrV1NQoKipKNptNPj4+WrJkiebPn6+qqiotW7ZMY8eOlY+Pjz7++ONG55oyZYqGDx+umTNnXrN+q9Xqsh+Eb5+7YU5ReXk5P3xO5so/RzRGr41Dr41Dr41zo71uyXsND0UNd3tlZ2dr9+7djfbl5+dr5cqVSktL06JFixQQEKCFCxdqwoQJkqS8vDwlJCTorbfeUu/evZWcnCyr1arY2FjV1tYqNDRUmzZtcowsbdiwQampqYqMjJS3t7eioqL0zDPPGP2VrxsTrQEAMI7hoSg+Pl7x8fFX3R8VFaWoqKgm94WHhys/P9/x2svLS/PmzdO8efOaPH7IkCHauHFjs+p69dVXm3WckVjVGgAA47jffehw4KGwAAAYh1Dkxrh8BgCAcQhFbozLZwAAGIdQ5Ma4fAYAgHEIRW6s4fLZuXPnVFtba3I1AAC0bYQiN9a9e3dZLBZJl9cqAgAArkMocmNWq1Xdu3eXxCU0AABcjVDk5phsDQCAMQhFbo7J1gAAGINQ5OZYqwgAAGMQitwcl88AADAGocjNMVIEAIAxCEVujpEiAACMQShyc0y0BgDAGIQiN8flMwAAjEEocnNcPgMAwBiEIjfH5TMAAIxBKHJzDZfPGCkCAMC1CEVurmGkqKqqSjU1NSZXAwBA20UocnPdu3eXxWKRJJWXl5tcDQAAbRehyM116NBBPXr0kMQlNAAAXIlQ1Aow2RoAANcjFLUCrFUEAIDrEYpaAdYqAgDA9QhFrUDDnKJ33nlH+/fvl81mM7kiAADanhaFolWrVqmkpMRVtaAJWVlZ2r59uyQpIyNDY8aMUXBwsLKyskyuDACAtqVFoeiTTz7R+PHjFRcXp+3bt+vSpUuuqgu6HIhiYmJUVVXVaHtJSYliYmIIRgAAOFGLQtHatWu1f/9+jR49Whs2bNCoUaP07LPP6uOPP3ZVfe2WzWbTrFmzZLfbr9jXsG327NlcSgMAwElaPKfopptuUnx8vLZt26b169frk08+UWxsrO677z5lZGSorq7OFXW2O7m5uTp16tRV99vtdhUXFys3N9fAqgAAaLs8WvqG2tpa7du3T9u2bdO7776rvn37asGCBQoICNDq1av14Ycf6uWXX3ZFre1KWVmZU48DAADX1qJQ9Oyzz2rPnj2SpPvvv1+vv/66Bg4c6Njv7++vRx991LkVtlP+/v5OPQ4AAFxbi0JRaWmpfvOb3+juu++Wl5fXFfv9/f0ZJXKSyMhIBQYGqqSkpMl5RRaLRYGBgYqMjDShOgAA2p4WzSlav369fvrTnzYZiKTLDy+98847nVJYe2e1WpWeni5JjgfCNmh4nZaWJqvVanhtAAC0RSze6Maio6OVmZmpgICARtsDAwOVmZmp6OhokyoDAKDtIRS5uejoaBUVFSkkJETS5XldX3zxBYEIAAAnIxS1AlarVYMGDZJ0+ZEfXDIDAMD5nBKKDh8+7IzT4Boa7jLjFnwAAFyjWaFo2LBhjV4/99xzjV7Hx8c7ryI0qXfv3pIu3wEIAACcr1mh6Nu3hO/cufOa++F8jBQBAOBazQpF374l/Nsh6Nv74XwNoYiRIgAAXOO65hQRgozXcPmMkSIAAFyDu89aiYaRooqKCl24cMHkagAAaHua9ZgPu92usrIyx2Wz+vr6Rq+ZU+R63bp1k4+Pjy5cuKCysjL16dPH7JIAAGhTmhWKLly4oKioKMdru93ueG2327mcZgCLxSJ/f3+dOHFCpaWlhCIAAJysWaHonXfecXUdaIbevXvrxIkTzCsCAMAFmhWKvv3sLZiDO9AAAHCdZk+03rFjh7KysiRJZ86c0RNPPKFhw4Zp/vz5qq2tdVmB+D/cgQYAgOs0KxT95S9/0W9+8xtdunRJkvT73/9elZWVWrZsmb788kutXbvWpUXiMkaKAABwnWaFoi1btmjFihV69NFHVVNTo5ycHM2dO1djxozRr3/9a+3YscPVdUKMFAEA4ErNCkVFRUWKjIyUJH3yySeqq6vTj3/8Y0lScHCwTp8+7boK4cBIEQAArtPiZ58dPnxYt956qzp37ixJKi8vl4dHs+Zr4wYxUgQAgOs0KxT169dP77//viRpz549uvPOOx373nvvPd12222uqQ6NNIwUlZeXs6o1AABO1qwhnmnTpunpp5+Wv7+//vnPfyo1NVWS9OKLL+q//uu/9Pzzz7u0SFzWvXt3dezYURcvXtQ///lP3XLLLWaXBABAm9GskaK7775b//Ef/6FJkybp9ddfV2BgoCTp448/1rx58zRhwgSXFonLGla1lphXBACAszV7naLw8HBNmzZNt956q2Pbli1bNHny5BZ/aGFhoeLj4zV8+HCNGjVKKSkpOnv2rCQpIyND48aNU1hYmMaNG6ctW7Zc9TyVlZVKTk5WRESEhg0bpri4OH366aeO/cXFxUpISNDw4cM1cuRIpaSk6Ny5c479Bw8eVGxsrMLDw3XXXXfpd7/7ndtflmJeEQAArtGsy2cvv/zydx7z1FNPNesDL168qGnTpmny5Mlau3atzp8/r3nz5mnBggWaPHmy0tPT9corr2jIkCH6+OOP9cQTT6hv374aMWLEFedatGiRamtrlZOTIx8fH61cuVKJiYnat2+fJGnu3LkKDw/XH//4R50/f15PPfWUli5dqiVLlujLL7/UL3/5S82fP18PPfSQTp8+raeeekqpqan69a9/3azvYgZGigAAcI1mh6IuXbpo4MCBje5Ea9CSB8KWlpZqwIABSkpKktVqlZeXl2JjY5WSkqI1a9Zo79696ty5s+rq6lReXi6LxaKuXbs2ea7ly5ervr5e3t7eqqys1Llz59SjRw/H/uPHj+v222+X3W53PLjWx8dH0uVRpKioKMdIl7+/vx544AFlZmY2+7uYgZEiAABco1mhaN68ecrKytLp06f18MMP68EHH9RNN910XR/Yp08frV+/vtG2PXv2aPDgwZKkzp0768SJE5o4caJsNpvi4+M1aNCgJs/l6ekpSVqxYoXWrl2rTp06NVpde+bMmVq2bJk2b94sm82m0NBQJScnS7p8OTA8PNxxbH19vXJychx1uCtGigAAcI1mhaL4+HjFx8fr448/1ptvvqmJEydq2LBhevjhh3XXXXepQ4dmT01qxG63Ky0tTfv27Ws0dygoKEiHDx9WYWGhEhMT5efnp+nTp1/1PDNmzFBSUpIyMjKUkJCg7du3KygoSBaLRTNmzFB8fLzKy8s1d+5cPfvss3rppZcavb+2tla//vWvVVxc7Liz7mpsNptsNtt1fd9rnfOb/3stN998s6TLocjZdbQHLek1bgy9Ng69Ng69No6zet2S91vsTV0P+w4XL17U7t27tXXrVhUVFemBBx7Q3LlzW3SOqqoqzZ8/X0ePHtXq1avVv3//Jo9bt26dduzYoe3btzfrvBMmTNDkyZMVHh6uKVOm6NChQ47FJT/66CM9/vjjysvLcyw+efr0ac2ZM0dVVVVas2aNYyTm26qrqxtN4jbLgQMH9NRTT6lPnz56/fXXzS4HAIBWYeDAgfL19b3mMde1FHXHjh01duxY1dbWatOmTdq4cWOLQtHJkyeVkJCg3r17KzMzU35+fpKkjRs3qqCgQGlpaY5ja2pq1K1btybP88gjj2jq1KkaP378FceXlZXJZrOpvr7esc/T01MWi0VWq1XS5SUFEhMTNWLECD3//POO+UbX0q9fv+9sakvZbDYdOXJEISEhjtqupiHgVVRUKDQ01Kl1tAct6TVuDL02Dr02Dr02jrN6XV1drWPHjjXr2BaHog8++EBvvvmm9u7dq1tuuUWPPPKIJk6c2Oz3V1ZWKi4uTiNGjNALL7zQ6NJbeHi4UlNTtWvXLo0fP175+fnavHmzFi9e3OS5hg4dqlWrVikkJEQ9e/bUmjVrVFNTo6ioKNlsNvn4+GjJkiWaP3++qqqqtGzZMo0dO1Y+Pj4qLi7Wk08+qSlTpmjWrFnNrt9qtbrsB6E55w4KCpIknT17VrW1terYsaNLamnrXPnniMbotXHotXHotXFutNcteW+zQlFRUZG2bt2qbdu2qba2VhMnTtR//ud/XvWS17VkZWWptLRU2dnZ2r17d6N9+fn5WrlypdLS0rRo0SIFBARo4cKFjsUh8/LylJCQoLfeeku9e/dWcnKyrFarYmNjVVtbq9DQUG3atMkxsrRhwwalpqYqMjJS3t7eioqK0jPPPCNJ2rRpk77++mtt3LhRGzdudNTQu3dvvfXWWy3+Xkbp0aOHvL29denSJf3zn/9UcHCw2SUBANAmNGtO0cCBA9WjRw/df//9Gj16dJMPgP3xj3/skgLdRcOcouZck2wpm82mgoIChYaGNivR3nLLLSoqKtIHH3ygkSNHOrWWtq6lvcb1o9fGodfGodfGcVavW/L7u1kjRXa7XWfPntWmTZu0adOmK/ZbLBa3mITcXvj7+6uoqIjb8gEAcKJmhaLCwkJX14EWYAFHAACc7/oWGIKpWMARAADnIxS1QowUAQDgfISiVoiRIgAAnI9Q1Ar16tVLkvTpp59q//79LDcPAIATEIpamaysLMXHx0uSiouLNWbMGAUHBysrK8vkygAAaN0IRa1IVlaWYmJi9OWXXzbaXlJSopiYGIIRAAA3gFDUSthsNs2aNUtNrbXZsG327NlcSgMA4DoRilqJ3NxcnTp16qr77Xa7iouLlZuba2BVAAC0HYSiVqK5t99zmz4AANeHUNRKNNyG76zjAABAY4SiViIyMlKBgYGyWCxN7rdYLAoKClJkZKTBlQEA0DYQiloJq9Wq9PR0SboiGDW8TktL46nNAABcJ0JRKxIdHa3MzEwFBAQ02h4YGKjMzExFR0ebVBkAAK0foaiViY6OVlFRkd58803HtsLCQgIRAAA3iFDUClmtVk2aNEmdOnWSdHllawAAcGMIRa2UxWJRnz59JEnHjx83uRoAAFo/QlErduutt0oiFAEA4AyEolaMUAQAgPMQiloxQhEAAM5DKGrFGkLRiRMnTK4EAIDWj1DUin0zFNXX15tcDQAArRuhqBX7wQ9+IKvVqosXL/IgWAAAbhChqBXz9PTUD3/4Q0nMKwIA4EYRilo5JlsDAOAchKJWjlAEAIBzEIpaOVa1BgDAOQhFrRwjRQAAOAehqJUjFAEA4ByEolau4fLZ2bNnVVFRYW4xAAC0YoSiVq5Lly76/ve/L4mVrQEAuBGEojaAS2gAANw4QlEbQCgCAODGEYraAEIRAAA3jlDUBhCKAAC4cYSiNoBQBADAjSMUtQENt+UXFxfr0qVLJlcDAEDrRChqA3r16qVOnTrJbrerqKjI7HIAAGiVCEVtgMVi0S233CJJ2rBhg/bv3y+bzWZyVQAAtC6EojYgKytLn3/+uSTppZde0pgxYxQcHKysrCyTKwMAoPUgFLVyWVlZiomJ0cWLFxttLykpUUxMDMEIAIBmIhS1YjabTbNmzZLdbr9iX8O22bNncykNAIBmIBS1Yrm5uTp16tRV99vtdhUXFys3N9fAqgAAaJ0IRa1YWVmZU48DAKA9IxS1Yv7+/k49DgCA9oxQ1IpFRkYqMDBQFoulyf0Wi0VBQUGKjIw0uDIAAFofQlErZrValZ6eLklXBKOG12lpabJarYbXBgBAa0MoauWio6OVmZmpgICARtsDAwOVmZmp6OhokyoDAKB1IRS1AdHR0SoqKtK6deskSZ06ddKJEycIRAAAtAChqI2wWq36+c9/Lk9PT50/f14lJSVmlwQAQKtCKGpDvLy8NHDgQEnS4cOHTa4GAIDWhVDUxvzoRz+SRCgCAKClCEVtTEMoKigoMLcQAABaGVNCUWFhoeLj4zV8+HCNGjVKKSkpOnv2rCQpIyND48aNU1hYmMaNG6ctW7Zc9TyVlZVKTk5WRESEhg0bpri4OH366aeO/cXFxUpISNDw4cM1cuRIpaSk6Ny5c479X3zxheLi4hQWFqY777xTa9ascd2XNggjRQAAXB/DQ9HFixc1bdo0hYWF6b333tPOnTtVUVGhBQsWaO/evUpPT9fy5cuVn5+v1NRUvfjiizpw4ECT51q0aJGqqqqUk5OjgwcPaujQoUpMTHTsnzt3rvr27av3339f2dnZKi0t1dKlSyVJtbW1+uUvf6mQkBAdPHhQ//Ef/6GMjAxlZ2cb0gdXaQhFx48f19dff21yNQAAtB6Gh6LS0lINGDBASUlJ8vLyUo8ePRQbG6tDhw4pKipKe/fu1ZAhQ1RXV6fy8nJZLBZ17dq1yXMtX75c6enp6tq1q6qrq3Xu3Dn16NHDsf/48eOy2+2OfywWi3x8fCRJhw4d0unTp/X000/Ly8tLgwYN0pQpU5SRkWFIH1ylZ8+e6t27tyTpyJEjJlcDAEDrYXgo6tOnj9avX99oleU9e/Zo8ODBkqTOnTvrxIkTGjp0qKZPn65HH31UgwYNavJcnp6e8vb21ooVKxQREaGdO3dqwYIFjv0zZ87Uli1bFBoaqhEjRqimpkbJycmSpM8++0y33HKLvLy8HMf37dtXhYWFrvjahuISGgAALedh5ofb7XalpaVp3759jeYOBQUF6fDhwyosLFRiYqL8/Pw0ffr0q55nxowZSkpKUkZGhhISErR9+3YFBQXJYrFoxowZio+PV3l5uebOnatnn31WL730ks6fP+8YNWrg4+Oj6urqa9Zss9lks9lu7Is3cc5v/u+NCgkJUXZ2tgoKCpxea2vn7F7j6ui1cei1cei1cZzV65a837RQVFVVpfnz5+vo0aPasmWL+vfv79jn6ekp6fIv95///OfasWPHNUNRx44dJUnx8fF644039M477yg8PFzp6ek6dOiQPDw85Ovrq5SUFD3++ONavHixfH19deHChUbnuXDhgjp16nTNuo8dO3a9X/k7OetyV7du3SRJH374IXehXQWXFo1Dr41Dr41Dr41jZK9NCUUnT55UQkKCevfurczMTPn5+UmSNm7cqIKCAqWlpTmOrampcfyS/7ZHHnlEU6dO1fjx4684vqysTDabTfX19Y59np6eslgsslqtuu2221RUVKS6ujp5eFxuw+eff67bbrvtmrX369dPvr6+1/vVm2Sz2XTkyBGFhIQ45eGt3t7eWrhwoY4fP+60c7YVzu41ro5eG4deG4deG8dZva6urm72gIbhoaiyslJxcXEaMWKEXnjhBXXo8H/TmsLDw5Wamqpdu3Zp/Pjxys/P1+bNm7V48eImzzV06FCtWrVKISEh6tmzp9asWaOamhpFRUXJZrPJx8dHS5Ys0fz581VVVaVly5Zp7Nix8vHxUUREhHr06KFly5Zp9uzZ+uKLL/Tqq69qzpw516zfarW67AfBWeceMGCAOnbsqOrqahUVFalfv35OqK5tceWfIxqj18ah18ah18a50V635L2Gh6KsrCyVlpYqOztbu3fvbrQvPz9fK1euVFpamhYtWqSAgAAtXLhQEyZMkCTl5eUpISFBb731lnr37q3k5GRZrVbFxsaqtrZWoaGh2rRpk2NkacOGDUpNTVVkZKS8vb0VFRWlZ555RpLk4eGhV155Rc8995xGjRolX19fTZkypU08RNXDw0NDhgxRXl6eDh8+TCgCAKAZDA9F8fHxio+Pv+r+qKgoRUVFNbkvPDxc+fn5jtdeXl6aN2+e5s2b1+TxQ4YM0caNG6/6WT/84Q+1YcOG5hXeygwdOlR5eXn685//rJ49eyoyMpK/1QAAcA085qMNysrKUlZWliTpL3/5i8aMGaPg4GDHNgAAcCVCURuTlZWlmJgYVVRUNNpeUlKimJgYghEAAFdBKGpDbDabZs2aJbvdfsW+hm2zZ89mfQ0AAJpAKGpDcnNzderUqavut9vtKi4uVm5uroFVAQDQOhCK2pCysjKnHgcAQHtCKGpD/P39nXocAADtCaGoDYmMjFRgYKAsFkuT+y0Wi4KCghQZGWlwZQAAuD9CURtitVqVnp4uSVcNRmlpaaxXBABAEwhFbUx0dLQyMzMVEBDQaHv37t2VmZnZJlbsBgDAFQhFbVB0dLSKioq0b98+Pfroo5Kku+66i0AEAMA1GP6YDxjDarVq9OjR8vHx0Wuvvabc3FzV19c3egAvAAD4P/yGbOOGDRumTp06qby8XEeOHDG7HAAA3BahqI3z9PTUnXfeKUn661//anI1AAC4L0JRO/CTn/xEEqEIAIBrIRS1Aw2h6N13323yuWgAAIBQ1C6Eh4fLx8dHZ86c0T/+8Q+zywEAwC0RitoBLy8v3XHHHZK4hAYAwNUQitoJ5hUBAHBthKJ2oiEUvf322/rzn/+s/fv3y2azmVwVAADug1DUTpSWlkqSKioq9Pjjj2vMmDEKDg5WVlaWyZUBAOAeCEXtQFZWlh577LErtpeUlCgmJoZgBACACEVtns1m06xZs5q8Fb9h2+zZs7mUBgBo9whFbVxubq5OnTp11f12u13FxcXKzc01sCoAANwPoaiNKysrc+pxAAC0VYSiNs7f39+pxwEA0FYRitq4yMhIBQYGymKxNLnfYrEoKChIkZGRBlcGAIB7IRS1cVarVenp6ZJ0RTBqeJ2Wliar1Wp4bQAAuBNCUTsQHR2tzMxMBQQENNrepUsXZWZmKjo62qTKAABwH4SidiI6OlpFRUXat2+fnnrqKUlSr169NGnSJJMrAwDAPRCK2hGr1arRo0frhRdekLe3tz777DMdPXrU7LIAAHALhKJ2qGvXrho3bpwkKTMz0+RqAABwD4SidiomJkaS9Oabb5pcCQAA7oFQ1E7df//98vDw0CeffKJly5Zp//79POoDANCuEYraqX379jluw09OTtaYMWMUHBzMw2EBAO0WoagdysrKUkxMjC5dutRoe0lJiWJiYghGAIB2iVDUzthsNs2aNUt2u/2KfQ3bZs+ezaU0AEC7QyhqZ3Jzc3Xq1Kmr7rfb7SouLlZubq6BVQEAYD5CUTtTVlbm1OMAAGgrCEXtjL+/v1OPAwCgrSAUtTORkZEKDAy84uGwDSwWi4KCghQZGWlwZQAAmItQ1M5YrValp6dL0lWDUVpamuN2fQAA2gtCUTsUHR2tzMxMBQQEXLEvKipK0dHRJlQFAIC5PMwuAOaIjo7WAw88oNzcXJWVlenMmTN6+umn9d5772nbtm2qrq6Wv7+/IiMjGTUCALQLhKJ2zGq1avTo0ZIu34q/YsUKffHFF3rwwQcdxwQGBio9PZ3RIwBAm8flM0iStm7dqi+++OKK7axyDQBoLwhFcKxy3RRWuQYAtBeEIrDKNQAAIhRBrHINAIBEKIJY5RoAAIlQBLHKNQAAEqEIYpVrAAAkQhH+v2utcv3QQw/Jz89Pr732mvbv389daACANonFG+Hw7VWujx07pt/85jfKzMxUZmam4zgWdAQAtEWMFKGRhlWuH330UQ0ZMqTJY1jQEQDQFhGK0CSbzabZs2c3uY8FHQEAbZEpoaiwsFDx8fEaPny4Ro0apZSUFJ09e1aSlJGRoXHjxiksLEzjxo3Tli1brnqeyspKJScnKyIiQsOGDVNcXJw+/fRTSVJeXp7CwsIa/TNkyBD1799fX375pSTpgw8+UHR0tIYNG6YxY8bo5ZdfdvzCb+9Y0BEA0N4YPqfo4sWLmjZtmiZPnqy1a9fq/PnzmjdvnhYsWKDJkycrPT1dr7zyioYMGaKPP/5YTzzxhPr27asRI0Zcca5FixaptrZWOTk58vHx0cqVK5WYmKh9+/YpPDxc+fn5jmOrqqoUGxur++67T7169VJ5ebkSExOVmpqqe+65R8ePH9cTTzyhwMDARg9Eba9Y0BEA0N4YHopKS0s1YMAAJSUlyWq1ysvLS7GxsUpJSdGaNWu0d+9ede7cWXV1dSovL5fFYlHXrl2bPNfy5ctVX18vb29vVVZW6ty5c+rRo0eTx/7ud79Tr169lJiY6KjjwoULqq+vd4wOWSwW+fj4uOaLtzLNXajxyy+/lM1m43Z9AECrZ3go6tOnj9avX99o2549ezR48GBJUufOnXXixAlNnDhRNptN8fHxGjRoUJPn8vT0lCStWLFCa9euVadOnbR27dorjsvLy9OuXbuUnZ3t2DZo0CCNHz9eM2fOlNVqlc1m05QpU3Tvvfdes36bzeb0eTQN53On+Tl33HGHAgMDVVJScs1LinPmzNGyZcu0YsUKTZo0ycAKr4879rqtotfGodfGodfGcVavW/J+i93ESTR2u11paWn685//rC1btqh///6SpNraWkmX5x4lJiZqypQpmj59+lXPc/HiRXXo0EEZGRlauXKltm/frqCgIMf+uLg4DRgwQPPnz3dsu3TpkpYsWaKRI0fq7rvv1pEjR5SUlKS5c+fq4YcfvuIzqqurHfOV2ou9e/cqJSWl2ce/+OKLioqKcmFFAABcn4EDB8rX1/eax5gWiqqqqjR//nwdPXpUq1evdgSib1u3bp127Nih7du3N+u8EyZM0OTJkzV16lRJ0smTJ3XvvfcqJydHgYGBjuNeeeUVvf/++9qwYYNj2+rVq5WTk9PkreYNoahfv37f2dSWstlsOnLkiEJCQtzuMtTWrVs1Z86ca066li5fegwICNDx48fd7jt8kzv3uq2h18ah18ah18ZxVq+rq6t17NixZoUiUxZvPHnypBISEtS7d29lZmbKz89PkrRx40YVFBQoLS3NcWxNTY26devW5HkeeeQRTZ06VePHj7/q8Xv27NGwYcMaBSLp8pyimpqaRts8PDwcl+Suxmq1uuwHwZXnvl4xMTGaNGmSVq1apTlz5lz1OLvdrlOnTumDDz7Q6NGjjSvwOrljr9sqem0cem0cem2cG+11S95r+C35lZWViouL07Bhw7RhwwZHIJKk8PBw/fd//7d27dql+vp6ffTRR9q8ebMeffTRJs81dOhQrVq1SiUlJaqpqdHKlStVU1PT6BLORx99pPDw8CveGxUVpY8++khbt26V3W5XYWGhXn31Vf3sZz9z/pdu5axWq3r16tWsY998800eBQIAaJUMD0VZWVkqLS1Vdna2br/99ivWEVq5cqXWrFmj8PBw/eY3v9HChQs1YcIESf+39lBpaakkKTk5WXfddZdiY2MVGRmpo0ePatOmTY1Gik6dOtXkL/Q77rhDqamp+tOf/qTbb79dTz/9tJ588kk99thjxjSilWnu3Wgvv/yyxowZo+DgYFa8BgC0KqZOtG5NGuYUNeeaZEvZbDYVFBQoNDTUbYdjbTabgoODv/NutAYWi0WSlJmZ6VbPSGsNvW4r6LVx6LVx6LVxnNXrlvz+5jEfaBar1ar09HRJ/xd4rsVut8tutyshIUHvvPMOl9MAAG6PUIRmi46OVmZmpgICApr9nrNnz+qee+7hchoAwO0RitAi0dHRKioq0r59+/TUU081+30lJSWKiYkhGAEA3JYpt+SjdbNarY7b7l9++eVmvadhHtIvf/lLXbhwQQEBAYqMjOSaPADAbTBShOsWGRmpwMDAZs0xavCvf/1LTzzxBHeoAQDcDqEI162lk6+/jUtqAAB3QijCDbmeydcNuEMNAOBOCEW4YQ2Tr//7v/+70QrlzfXNO9TeeOMN7d+/X6+99horYwMADMVEaziF1WrV3XffrXXr1ikmJkaSmrXI4zedOnVKkydPbrQtMDBQ6enpbrUAJACgbWKkCE51I5fTmnLq1Ck99NBDmjNnDiNHAACXIhTB6b65ltGWLVvUs2fP65qI/U1paWmOO9a4xAYAcAUun8ElvrmWkY+Pj2JiYmSxWFp8Se3brnaJbfny5erZs6fKysrk7++vO+64Qx988IHjNWsiAQC+C6EILtdwSW3WrFk6deqU08/fVFCyWq2NRpAagpOfn58OHDigiooKRUZGEpwAAA6EIhgiOjpaDzzwgPbv36/Jkyfr7NmzLv28b19Sa0lw+q4RJ0nKzc1t0TFX20YIAwD3QSiCYZxxh5ozXU9wuummmyRJX331VYuOaWpbQECApk+frttuu+2GApcrg9uNnHv//v3XHJVzhxpbQx9d0Wuze+SufWxprxumCLhbja2hj991jFl/YSQUwXCuvpzmTN8OTt8MNS05pqltJSUlWrx4seP19QYuVwY3Iz+fGqmRGttnjU2N2qenp+uBBx6Q0Sx2M/+q3opUV1fr008/1cCBA+Xr6+vUc9tsNhUUFCg0NLRdXU6x2WyN/rZw5swZzZkzx+2DEgDAdRruVn799dd1yy233PDvxpb8/makCKb55h1qDSZNmqTc3Fxt27ZNaWlpTrljDQDQetjtdlksFs2ZM0dvvvmmoZ/NOkVwKw1BacWKFXrzzTedtggkAKD1sNvtOnXqlPLz8w39XEaK4LYa7ljjEhsAtE9nzpwx9PMIRXBr17rEdq2g9O2JewCA1ud73/ueoZ9HKEKr05yg9O1bPAlOANB6WCwWBQQEKCwszNDPJRShTWgqKDUVnBrWGBkxYsQV67k0Jzg587ZYAMCVGu4+W7FiheF3ZBOK0G40BKfu3bs7bvFs6YiTsxZQ++yzz7Ru3bpGAczstULM/nxqpEZqbJ81NrVOUVpamh544AEVFBTISIQi4BuaM+LU1LbmHPPtbQsXLnSrlWddtfJvU6Ny7lJja+ijK3ptdo/ctY8t7TUrWrt2RWszpjeweGMzsXhj20CvjUOvjUOvjUOvjeOsXrfk9zfrFAEAAIhQBAAAIIlQBAAAIIlQBAAAIIlQBAAAIIlQBAAAIIlQBAAAIIlQBAAAIIlQBAAAIInHfDRbfX29JOnChQtOP3fDUubV1dWskOpi9No49No49No49No4zup1w+/tht/j18JjPprpq6++UlFRkdllAACA6xAcHOx4IO3VEIqaqa6uTpWVlfL29laHDlx1BACgNaivr9elS5fUrVs3eXhc+wIZoQgAAEBMtAYAAJBEKAIAAJBEKDLVV199pcTERIWHhysiIkIvvPCC6urqzC6rTSgsLFR8fLyGDx+uUaNGKSUlRWfPnpUkHT58WA8//LDCwsIUFRWlN954w+Rq2wabzaYpU6boV7/6lWMbvXa+iooKpaSkKCIiQj/+8Y+VmJio06dPS6Lfznb06FE9/vjjCg8P15133qnf/e53qqmpkUSvneXs2bMaO3asDh486Nj2Xb3dunWrxo4dq9DQUEVHRys/P995BdlhmieeeML+7//+7/bq6mr7yZMn7ffdd5993bp1ZpfV6l24cME+atQoe3p6uv3SpUv2s2fP2hMSEuy/+MUv7BUVFfbhw4fbt2zZYq+trbV/8MEH9rCwMPvhw4fNLrvVS0tLsw8YMMA+b948u91up9cu8sQTT9iTkpLslZWV9q+//tr+1FNP2adPn06/ncxms9lHjRpl37Rpk91ms9nLysrs9957r/3ll1+m106Sl5dnv+eee+z9+vWzHzhwwG63f/d/Nw4cOGAPCwuz5+Xl2Wtqaux/+tOf7BEREfbq6mqn1MRIkUn+93//V3/729/0zDPPyMfHR0FBQUpMTFRGRobZpbV6paWlGjBggJKSkuTl5aUePXooNjZWhw4d0ttvv63u3bvr8ccfl4eHh0aOHKn777+fvt+gDz/8UG+//bbGjRvn2Eavne+TTz7R4cOHtXTpUnXt2lWdO3fW888/r+TkZPrtZJWVlfrXv/6l+vp62f///UgdOnSQj48PvXaCrVu3Kjk5WXPmzGm0/bt6+8Ybb+i+++7T7bffLk9PT02dOlU9evTQrl27nFIXocgkn332mbp3765evXo5tt16660qLS3VuXPnTKys9evTp4/Wr1/faLGvPXv2aPDgwfrss8/Ur1+/Rsf37dtXhYWFRpfZZnz11VdauHChli1bJh8fH8d2eu18H3/8sfr27avXX39dY8eO1Z133qk//OEP6tmzJ/12sh49emjq1Kn6wx/+oJCQEP3kJz9RcHCwpk6dSq+d4M4771ROTo4mTJjQaPt39fbzzz93ae8JRSY5f/58o18gkhyvq6urzSipTbLb7VqxYoX27dunhQsXNtn3jh070vPrVF9fr2eeeUbx8fEaMGBAo3302vkqKyv1P//zPyoqKtLWrVv1l7/8RV9++aXmzZtHv52svr5eHTt21K9//WsVFBRo586dOn78uFauXEmvnaBnz55Nrhn0Xb11de8JRSbx9fW94pEhDa87depkRkltTlVVlZ5++mnt2LFDW7ZsUf/+/eXj46OLFy82Ou7ixYv0/DqtXbtWXl5emjJlyhX76LXzeXl5SZIWLlyozp0763vf+55mz56tv/71r7Lb7fTbiXJycrRnzx499thj8vLy0m233aakpCS99tpr/LvtQt/VW1f3nlBkkttuu00VFRU6c+aMY9vx48d18803q0uXLiZW1jacPHlSDz30kKqqqpSZman+/ftLkvr166fPPvus0bGff/65brvtNjPKbPW2bdumv/3tbwoPD1d4eLh27typnTt3Kjw8nF67QN++fVVfX6/a2lrHtobnOQ0cOJB+O1FZWZnjTrMGHh4e8vT05N9tF/qu3t52220u7T2hyCTBwcG6/fbbtWTJElVVVam4uFh//OMfFRMTY3ZprV5lZaXi4uI0bNgwbdiwQX5+fo59Y8eO1ZkzZ7Rx40bV1tbqwIED2rFjhx566CETK269du/erb///e/Ky8tTXl6eJk6cqIkTJyovL49eu8Add9yhoKAgLViwQOfPn9fZs2e1YsUK3XPPPZo4cSL9dqI777xT//rXv7RmzRrZbDYVFxdr9erVuv/++/l324W+q7cxMTHasWOHDhw4oNraWm3cuFFfffWVxo4d65TP5zEfJjpz5oyee+45HTx4UB06dNCDDz6o5ORknrx8g/70pz9p6dKl8vHxkcViabQvPz9fR44c0QsvvKBjx47Jz89PiYmJio6ONqnatqVhjaKlS5dKEr12gS+//FJLly7VoUOHdOnSJUVFRWnhwoXq2rUr/XayDz74QGlpaTpx4oS6dOmin/3sZ467Wum18/Tv31+bN29WRESEpO/+78a2bdu0evVqffnll+rbt68WLVqkH/3oR06phVAEAAAgLp8BAABIIhQBAABIIhQBAABIIhQBAABIIhQBAABIIhQBAABIIhQBAABIIhQBAABIIhQBAABIIhQBaMfeeustDRkyRIWFhZKkf/zjHxo6dKjeffddkysDYAYe8wGgXZs/f76OHj2qV199VZMnT9a9996ruXPnml0WABMQigC0a9XV1YqOjlZNTY169+6tTZs28VBmoJ3i8hmAds3X11cPPfSQSkpKNGnSJAIR0I4xUgSgXTt58qQefPBBTZgwQTk5Odq2bZtuvvlms8sCYAJCEYB2q7a2Vo8++qgGDhyo559/Xk899ZQqKyu1adMmdejAQDrQ3vBTD6DdSk9PV3l5uX71q19Jkp577jl9/vnnWrt2rcmVATADI0UAAABipAgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAEASoQgAAECS9P8AX5rWkOXqMGoAAAAASUVORK5CYII=\n",
      "text/plain": [
       "<Figure size 640x480 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "fig = plt.figure()        \n",
    "ax = plt.axes()\n",
    "#x轴0-100\n",
    "x = np.arange(0, 100)\n",
    "#y轴mse_y列表\n",
    "y = mse_y\n",
    "#设置线型颜色样式标题等\n",
    "plt.plot(x, y,'-ok')\n",
    "plt.title(\"MSE\") \n",
    "plt.xlabel(\"x\") \n",
    "plt.ylabel(\"MSE y\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 20,
   "id": "2d58b010-ee28-44cd-9f59-946155e76a4b",
   "metadata": {},
   "outputs": [],
   "source": [
    "#保存散点图图片\n",
    "fig.savefig('mse.png')"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.13"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
