{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "9cbcc765-e1c2-4cd4-9984-8e29b55a6f12",
   "metadata": {},
   "outputs": [],
   "source": [
    "#导入numpy、pandas、matplotlib库\n",
    "#设置图表风格\n",
    "import pandas as pd\n",
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "%matplotlib inline\n",
    "plt.style.use('seaborn-whitegrid')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "a6df31db-f6c3-457b-94b9-1bd551999bc4",
   "metadata": {},
   "outputs": [],
   "source": [
    "train_ = pd.read_csv(r\"train.csv\")\n",
    "train_ = np.array(train_)\n",
    "train_x = train_[::,2:786]\n",
    "#给train_x集左边加上一列全1列，是为了后面与theta矩阵相乘多出一个偏移项。\n",
    "train_x = np.hstack([np.ones((20000,1)),train_x])\n",
    "#对train_x/1024是为了后面取以e为底的指数时，结果不至于数据溢出.\n",
    "train_x = train_x / 1024"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "7cc0432e-1473-4e45-877e-d43b0e363234",
   "metadata": {},
   "outputs": [],
   "source": [
    "#先分割出y训练集\n",
    "train_y0 = train_[::,1:2]\n",
    "#再将y训练集转置，作为后面独热编码进行的花式索引的其中一个轴。\n",
    "train_y1 = train_y0.T\n",
    "\n",
    "#先创建一个全0数组，然后将数组m和数组train_y0作为全0数组花式索引的xy轴。\n",
    "#例:m第一个元素取0时，trian_y0第一个元素取0，就表示第一个样本属于第0类，\n",
    "#在全0数组的花式索引中就表示将第一行第一列的那个元素取出。\n",
    "#再将取出的元素都加上1，那么样本1的label的独热编码就为[1,0,0,0,0,0,0,0,0,0]\n",
    "y = np.zeros((20000,10))\n",
    "m = np.arange(0,20000).reshape(1,20000)\n",
    "y[m,train_y1] += 1\n",
    "train_y = y"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "302e39ee-db3e-4ead-8487-add9e4b44daa",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "def softmax(X):\n",
    "    #先对分割出的x集取以e为底的指数\n",
    "    X_exp = np.exp(X)\n",
    "    #在进行按行求和\n",
    "    sum_ = X_exp.sum(1).reshape(len(X),1)\n",
    "    #利用广播机制，让X_exp中的每一个元素都除之前的行求和结果。\n",
    "    #得出的结果是每一个样本是第x类的概率。\n",
    "    return X_exp / sum_"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "3603be71-af2d-47e5-b193-09bd1f881b21",
   "metadata": {},
   "outputs": [],
   "source": [
    "def gradient_descent(X,y,theta,eta,n,lamda,eplison):\n",
    "    a = 0\n",
    "    while a<n:\n",
    "        #梯度下降\n",
    "        y_hat = softmax(np.dot(X,theta))\n",
    "        dj = np.dot(X.T,y_hat - y)\n",
    "        theta = theta - eta*dj - 2*theta*lamda\n",
    "        #以交叉熵损失作为限制条件，当最终的theta对应的交叉熵损失小于设置的eplison时，迭代停止。\n",
    "        y_hat1 = y_hat.max(axis=1)\n",
    "        cross_entropy = np.sum((-np.log(y_hat1)),axis = 0)\n",
    "        if cross_entropy < eplison:\n",
    "            break\n",
    "        a = a+1\n",
    "    return theta"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "01552de5-a71f-48f2-b632-103da4baa034",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "#得出最终的权重矩阵。\n",
    "#eta lamda 等参数大小由后面打印出的交叉熵损失确定\n",
    "theta = np.zeros((785,10))\n",
    "eta = 0.031\n",
    "n = 1e4\n",
    "lamda = 0.0001\n",
    "eplison  = 0.005\n",
    "theta_result = gradient_descent(train_x, train_y,theta,eta,n,lamda,eplison)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "5f00a560-1c7d-4b5d-af2d-45397b8ecc52",
   "metadata": {},
   "outputs": [],
   "source": [
    "#导入测试数据集\n",
    "test_ = pd.read_csv(r\"test_no_answer.csv\")\n",
    "test_ = np.array(test_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "6604de12-9adc-4463-a517-df6b6aa6e569",
   "metadata": {},
   "outputs": [],
   "source": [
    "#测试集x值的分割\n",
    "test_x = test_[::,1:785]\n",
    "test_x = np.hstack([np.ones((2000,1)),test_x])\n",
    "#对x集同样/1024，同样是为了防止数据溢出。\n",
    "test_x = test_x / 1024"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "d76efe4c-26fb-46af-8037-4fd847afdc81",
   "metadata": {},
   "outputs": [],
   "source": [
    "#得出每个测试集样本的分类\n",
    "predict_test_y = np.dot(test_x,theta_result)\n",
    "predict_test_y = softmax(predict_test_y)\n",
    "#返回每个样本是某个label概率的最大值的索引，即为这个样本的label\n",
    "result_ = predict_test_y.argmax(axis=1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "cba003be-da44-4303-a561-438067da876a",
   "metadata": {},
   "outputs": [],
   "source": [
    "#数据的导出\n",
    "result_ = result_.reshape(2000,1)\n",
    "result_ = np.hstack([np.arange(1,2001).reshape(2000,1),result_])\n",
    "result_ = pd.DataFrame(result_, columns=['id', 'label'])\n",
    "result_.to_csv('result4.csv')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "id": "f4fbc9cd-a858-4b7e-88a4-772d3497ed36",
   "metadata": {},
   "outputs": [],
   "source": [
    "#用训练集的x值预测y值，将预测的值与真实值对比，计算出预测正确的值占总样本数的占比。\n",
    "predict_train_y = np.dot(train_x,theta_result)\n",
    "predict_train_y = softmax(predict_train_y)\n",
    "result_ = predict_train_y.argmax(axis=1)\n",
    "result_ = result_.reshape(20000,1)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "38403dbc-be34-4a0f-abee-15fed86d4462",
   "metadata": {},
   "outputs": [],
   "source": [
    "#accurcy函数\n",
    "#将预测值与真实值相减，如果预测值和真实值相同，那么就为0，如果不相同，就不为0.\n",
    "#将相减之后的数组与全0数组比较，得出一个布尔值的数组，相等为1，不相等为0\n",
    "#求和的结果就是预测值和真实值相等的样本个数\n",
    "#再将相等个数除以总数就是accurcy\n",
    "def accurcy(y,y1):\n",
    "    a = y - y1\n",
    "    return np.sum(a == np.zeros((20000,1)) ) / len(y)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 13,
   "id": "7d09351b-22ba-445e-b137-64967cc4f28f",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.94005"
      ]
     },
     "execution_count": 13,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#计算accuracy\n",
    "accurcy(result_ , train_y0)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "6e78cb4f-07c8-4b63-98f0-618fb206f631",
   "metadata": {},
   "outputs": [],
   "source": [
    "#利用每一次梯度下降迭代出的theta，计算每一个theta对应的平均交叉熵损失，放入cross_entropy_y\n",
    "#作为散点图的y坐标\n",
    "def cross_entropy(X,y,theta,eta,n,lamda,eplison):\n",
    "    a = 0\n",
    "    cross_entropy_y = []\n",
    "    while a<n:\n",
    "        y_hat = softmax(np.dot(X,theta))\n",
    "        dj = np.dot(X.T,y_hat - y)\n",
    "        theta = theta - eta*dj - 2*lamda*theta\n",
    "        y_hat1 = y_hat.max(axis=1)\n",
    "        cross_entropy = np.sum((-np.log(y_hat1)),axis = 0) \n",
    "        cross_entropy = cross_entropy / len(y)\n",
    "        cross_entropy_y.append(cross_entropy)\n",
    "        if cross_entropy < eplison:\n",
    "            break\n",
    "        a = a+1\n",
    "    return cross_entropy_y"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 15,
   "id": "74acaeb0-d930-4e3d-8d12-f0cdeff6d71b",
   "metadata": {
    "tags": []
   },
   "outputs": [],
   "source": [
    "#得出散点图各个点的y值\n",
    "theta = np.zeros((785,10))\n",
    "eta = 0.031\n",
    "n = 1e4\n",
    "lamda = 0.0001\n",
    "eplison  = 0.005\n",
    "cross_entropy_y = cross_entropy(train_x, train_y,theta,eta,n,lamda,eplison)\n",
    "#以90为步长取100个点\n",
    "cross_entropy_y = cross_entropy_y[1000:10000:90]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "id": "9f1aafb5-5bde-43a6-83d1-29be4005d187",
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "Text(0, 0.5, 'cross entropy y')"
      ]
     },
     "execution_count": 16,
     "metadata": {},
     "output_type": "execute_result"
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAj0AAAG8CAYAAAA1lRThAAAAOXRFWHRTb2Z0d2FyZQBNYXRwbG90bGliIHZlcnNpb24zLjUuMiwgaHR0cHM6Ly9tYXRwbG90bGliLm9yZy8qNh9FAAAACXBIWXMAAA9hAAAPYQGoP6dpAACK6klEQVR4nO2dd3wU1f7+n00lDQKEnkgEElBAQUJRiRRRUKlr5Cr2riBNQfRyr3oRFP2KNEURsSEoGDegiPUSEK9CRAGxIEUCGHoIJT3Z7O+P/M4wuzuzO7O9PO/Xy5dkdnb3zNmZOc88n8/5HIPFYrGAEEIIISTEifB3AwghhBBCfAFFDyGEEELCAooeQgghhIQFFD2EEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCdMKaroQEJ1H+bgAhJPDZuXMn3nvvPfz44484deoUmjVrhssvvxwPPvgg0tLS/N08VRYuXIhXXnnF4T4///wzEhISNH3e2bNnMWvWLOTk5KBnz56eaCIhxIdQ9BBCHLJ8+XI899xz6N27Nx577DE0b94cBw8exJtvvomvvvoKb7/9Njp37uzvZjpk5cqVqq/FxcVp/pw//vgDq1evhtFo9ESzCCE+hqKHEKLKTz/9hFmzZuHWW2/F9OnTpe29e/fG1VdfDaPRiCeffBKffPKJH1vpnG7duvm7CYSQAIA5PYQQVZYuXYqkpCQ8+uijdq81adIETzzxBK699lqUlpYCAG6//XZMmTIFEyZMwGWXXYYHHngAAHDu3Dk8//zzGDRoELp27YqhQ4ciNzfX6vN+++033HnnnejRowe6d++Ou+66Czt27JBeP3XqFKZMmYIrr7wSXbt2xYgRI7B69WqPHesTTzyBu+66Cx9//DEGDx6MLl26YPjw4di4cSMAYMuWLbjjjjsAAHfccQduv/12t4954MCBmDt3Lp5//nn06tULvXr1wtSpU1FSUgIA2LBhAzp27IjvvvvO6n3bt29Hx44dUVBQ4LHjJyQcoNNDCFHEYrHgu+++w8CBA1VDQEOGDLHb9vnnn2PIkCF49dVXYTabUVlZiTFjxuDkyZMYP3480tLS8M0332D69Ok4efIkHnroIZSWluK+++5D7969sWDBAtTU1OC1117Dvffei/z8fCQlJWHq1KkoLi7Gf/7zHyQkJOCTTz7BtGnT0KpVK/Tu3dvhsdTW1ipuj4iIQETE+We/X3/9FcePH8eECROQmJiI+fPnY8KECfj222/RuXNnPPXUU5gxYwaeeuopq+905ZgFK1asQNu2bfHcc8/h1KlTmDNnDv766y989NFHyM7ORosWLbBmzRr07dtXek9eXh7S0tKYV0SITih6CCGKlJSUoKqqCqmpqbreFxERgWeffRbx8fEA6gf13bt3Y8WKFejRowcAIDs7G7W1tVi0aBFuvvlmFBYW4tSpU7j99tulfdq1a4cPP/wQpaWlSEpKQkFBAcaOHYtBgwYBqA+xJScnIzIy0mmb1HKOcnJyMGvWLOnvc+fOwWQy4YILLgAAxMfH47bbbsPmzZsxePBgdOjQAQDQoUMH6d+uHnNycjIAwGAw4O2330ZSUhKAegdt3Lhx+Pbbb9G/f3+MHDkSy5YtQ1lZGRISElBdXY3PP/8cd955JwwGg4ZfhBAioOghhCgiHBCz2azrfampqdLgDwAFBQVo06aNNPgLhg8fjtzcXOzYsQNZWVlo0qQJHn74YVx33XXo168fLr/8cjz++OPS/r1798bChQuxa9cu9OvXD1dddRWmTZumqU22YSVBkyZN7P4WggcAWrZsCQCoqKjw+DH369cPADBgwABJ8AD1Ia/o6Ghs3boV/fv3x4033og33ngDX3/9NUaOHIlvvvkGZ8+exciRI50fOCHECooeQogiycnJSEhIwOHDh1X3KS8vR3V1teRaAEBKSorVPmfOnLHbJt/v7NmzSEhIwPLly/Haa69h3bp1+PDDDxEXF4fhw4dj+vTpiI2Nxdy5c/H666/j888/xxdffIGIiAhcccUVeOaZZ5xOm+/ataumY7YN4wknpa6uzuH7XDlmQfPmza32iYiIQHJysrRP27Zt0bNnT6xevRojR47E6tWr0adPH7Rp00bTMRFCzsNEZkKIKn379sWWLVtQVVWl+LrJZMLll1+Obdu2qX5Go0aNcPLkSbvtJ06cAAA0btwYQH046//+7/+wefNmfPjhhxg5ciRWrlyJd999FwCkvJ7169fj888/x6OPPoqff/4Z//nPf9w9TI+j9ZgB4PTp01b7mM1mlJSUWLlQN954I7Zs2YL9+/fjf//7H6fME+IiFD2EEFXuuecenD59GnPnzrV7rbi4GG+++Sbatm3rcEp4z549UVRUhJ9++slq+yeffILo6Ghccskl+OKLL9CnTx+cOHECkZGR6N69O5555hk0bNgQR48eRVFREfr164cvvvgCQL1Auv/++3HFFVfg6NGjHj1mR2jJHwK0HbNg06ZNqK6ulv7+73//i9raWlx++eXStsGDByM+Ph5PPfUUGjRogGuvvdbNIyEkPGF4ixCiSrdu3TBx4kTMmzcP+/btw6hRo9C4cWPs2bMHb731FsrKyvDGG284TKg1Go1YsWIFHnnkEUyYMAFpaWlYv349Pv74YzzyyCNo2LAhLrvsMtTV1WHcuHF44IEHkJCQgM8//xznzp3DtddeizZt2qBly5aYOXMmSktLccEFF+DXX3/Fxo0b8eCDDzo9ju3bt6u+lp6ebhWec4TIvdmwYQMaNWqETp06uXzMgqNHj+Lhhx/GHXfcgSNHjuDll19G3759rWaHxcXF4YYbbsDKlSsxevRoNGjQQFN7CSHWUPQQQhzy8MMP4+KLL8by5cvx/PPP4/Tp02jZsiWuuuoqPPTQQ2jdurXD98fFxWHZsmWYM2cOFixYgNLSUrRr105azgGoz2t58803MX/+fEyfPh0VFRXIyMjAwoUL0adPHwDAK6+8gpdffhnz589HSUkJWrVqhUceeUSqi+OIf/zjH6qvzZ8/X3HqvRIZGRkYOnQoli9fjk2bNmHt2rUuH7PghhtuQMOGDTFp0iTEx8dj1KhRmDx5st1nDhgwACtXrmRoixA3MFi4ch4hhPiFgQMHolevXpg9e7bTfZ955hn89NNP+PTTT33QMkJCEzo9hBASwLz33nv466+/sHLlSjz//PP+bg4hQQ1FDyGEBDBbt27Fpk2bcPvtt7M2DyFuwvAWIYQQQsICTlknhBBCSFhA0UMIIYSQsICihxBCCCFhAROZZdTW1uLMmTOIjY2VFlskhBBCSGBTV1eHqqoqNGrUCFFR6tKGokfGmTNnUFhY6O9mEEIIIcQF0tPT0bRpU9XXKXpkxMbGAqjvNNvVlt3BbDZj9+7dyMzM1Lx2D3EN9rXvYF/7Fva372Bf+w5P9XVFRQUKCwulcVwNih4ZIqQVFxeH+Ph4j32u2WwGAMTHx/MC8jLsa9/BvvYt7G/fwb72HZ7ua2epKUxcIYQQQkhYQNFDCCGEkLCAoocQQgghYQFFDyGEEELCAooeQgghhIQFFD2EEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCCCFhAUUPIYQQQsICih5CCCGEhAUUPYQQQggJCyh6CCGEEBIWUPQQQgghJCyg6CGEEEJIWEDRQwghhJCwgKKHEEIIIWEBRQ8hhBBCwgKKHkIIIYSEBRQ9hBBCCAkLKHoIIYQQEhZQ9BBCCCEkLKDoIYQQQkhYQNFDCCGEkLCAoocQQgghYQFFDyGEEELCAooeQgghhIQFFD2EEEIICQv8JnqKi4sxduxYZGVloXfv3pg1axZqa2sV9924cSOGDRuGbt264brrrkN+fr7ifjNnzsQTTzyh+p1Tp07F7bff7pH2E0IIISS48JvomTRpEuLj47Fp0ybk5ubihx9+wDvvvGO3X2FhIcaPH4+JEydi69atGD9+PCZNmoRjx45J+5SUlGDKlClYtmyZ6vfl5uZi7dq13jgUQgghhAQBfhE9Bw4cQEFBAaZOnYq4uDikpaVh7NixWL58ud2+eXl5yMrKwqBBgxAVFYXrr78ePXv2xMqVKwEAZWVlGDJkCBo2bIjBgwcrft/evXuxaNEi3HTTTV49LkIIIYQELlH++NI9e/YgOTkZLVq0kLa1b98ehw8fxtmzZ9GwYUNp+969e5GZmWn1/g4dOmDXrl0AgNjYWHz22WdISUlRDG1VVlZi8uTJePrpp/HLL79g//79TttnNpthNptdPTzFz5P/n3gP9rXvYF/7Fva372Bf+w5P9bXW9/tF9JSVlSEuLs5qm/i7vLzcSvQo7dugQQOUl5cDAKKiopCSkqL6XTNmzMCVV16Jfv364ZdfftHUvt27d2vaTy87d+70yucSe9jXvoN97VvY376Dfe07fNXXfhE98fHxqKiosNom/k5ISLDaHhcXh8rKSqttlZWVdvsp8cknn2DXrl348MMPdbUvMzMT8fHxut7jCLPZjJ07d6Jr166IjIz02OcSe9jXvoN97VvY376Dfe07PNXX5eXlmgwLv4iejIwMnD59GidPnpRcmn379qFly5ZISkqy2jczMxO//fab1ba9e/eiS5cuTr9nzZo12L9/P6644goAQFVVFcxmM7KysvDJJ5+gdevWiu+LjIz0yonurc8l9rCvfQf72rewv30H+9p3uNvXWt/rl0Tm9PR09OjRA8899xxKS0tx6NAhLFq0CDk5OXb7Dh8+HAUFBVi3bh1qa2uxbt06FBQUYMSIEU6/Z+nSpdi2bRu2bt2KrVu34oEHHkCPHj2wdetWVcFDCCGEkNDEb1PWFyxYgNraWlx99dUYPXo0srOzMXbsWABA9+7d8cknnwCoT3B+9dVXsXjxYvTs2ROLFi3CwoULceGFF/qr6YQQQggJQvwS3gKAlJQULFiwQPG1bdu2Wf2dnZ2N7Oxsp585e/Zsh6+PHz9eewMJIYQQElJwGQpCCCGEhAUUPYQQQggJCyh6CCGEEBIWUPQQQgghJCyg6CGEEEJIWEDRQwghhJCwgKKHEEIIIWEBRQ8hhBBCwgKKHkIIIYSEBRQ9hBBCCAkLKHoIIYQQEhZQ9BBCCCEkLKDoIYQQQkhYQNFDCCGEkLCAoocQQgghYQFFDyGEEELCAooeQgghhIQFFD2EEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCCCFhAUUPIYQQQsICih5CCCGEhAUUPYQQQggJCyh6CCGEEBIWUPQQQgghJCyg6CGEEEJIWEDRQwghhJCwgKKHEEIIIWEBRQ8hhBBCwgKKHkIIIYSEBRQ9hBBCCAkLKHoIIYQQEhZQ9BBCCCEkLIjydwMIIUSO2WzGpk2bcOTIEbRq1QrZ2dmIjIz0d7MIISEARQ8hJGAwmUyYOHEi/v77b2lbamoq5s+fD6PR6MeWEUJCAYa3CCEBgclkQk5OjpXgAYCioiLk5OTAZDL5qWWEkFCBoocQ4nfMZjMmTpwIi8Vi95rYNmnSJJjNZl83jRASQlD0EEL8zqZNm+wcHjkWiwWHDh3Cpk2bfNgqQkioQdFDCPE7R44c8eh+hBCiBEUPIcTvtGrVyqP7EUKIEhQ9hBC/k52djdTUVBgMBsXXDQYD0tLSkJ2d7eOWEUJCCYoeQojfiYyMxPz58wHATviIv+fNm8d6PYQQt6DoIYQEBEajEbm5uWjTpo3V9tTUVOTm5rJODyHEbSh6CCEBg9FoxO7du6W/J0yYgP3791PwEEI8AkUPISSgqKmpkf6dmprKkBYhxGNQ9BBCAorKykrFfxNCiLtQ9BBCAoqKigrFfxNCiLtQ9BBCAgo6PYQQb0HRQwgJKCh6CCHegqKHEBJQyIUOw1uEEE9C0UMICSjkQodODyHEk1D0EEICCjo9hBBvQdFDCAkomNNDCPEWFD2EkICC4S1CiLeg6CGEBBQMbxFCvAVFDyEkoGB4ixDiLSh6CCEBBSsyE0K8BUUPISSgoNNDCPEWFD2EkICCOT2EEG9B0UMICSjo9BBCvAVFDyEkoOCUdUKIt/Cb6CkuLsbYsWORlZWF3r17Y9asWaitrVXcd+PGjRg2bBi6deuG6667Dvn5+Yr7zZw5E0888YTVtr///huPPPII+vTpg969e2Ps2LE4dOiQx4+HEOIZ5EKntrZW9b5AiF7MZjM2bNiADz74ABs2bIDZbPZ3k4iP8ZvomTRpEuLj47Fp0ybk5ubihx9+wDvvvGO3X2FhIcaPH4+JEydi69atGD9+PCZNmoRjx45J+5SUlGDKlClYtmyZ3fvHjRuHRo0aYf369Vi/fj2Sk5MxduxYbx4aIcQNbN0duj3EE5hMJqSnp2PAgAEYM2YMBgwYgPT0dJhMJn83jfgQv4ieAwcOoKCgAFOnTkVcXBzS0tIwduxYLF++3G7fvLw8ZGVlYdCgQYiKisL111+Pnj17YuXKlQCAsrIyDBkyBA0bNsTgwYOt3nvmzBmkpKRg4sSJiI+PR0JCAu644w7s3r0bZ86c8cmxEkL0YZu8zGRm4i4mkwk5OTn4+++/rbYXFRUhJyeHwieMiPLHl+7ZswfJyclo0aKFtK19+/Y4fPgwzp49i4YNG0rb9+7di8zMTKv3d+jQAbt27QIAxMbG4rPPPkNKSopdaKtRo0ZYunSp1bYvv/wSbdq0QaNGjVTbZzabPWp7is+ilep92Ne+w1t9bStyysrK0KRJE49+h78wm83YtGkTjh49ipYtWyI7OxuRkZGa3yv/P9GG2WzGxIkTYbFY7F6zWCwwGAyYOHEihg4dKv0W7Gvf4am+1vp+v4iesrIyxMXFWW0Tf5eXl1uJHqV9GzRogPLycgBAVFQUUlJSNH3vBx98gLfeeguvvfaaw/12796t6fP0snPnTq98LrGHfe07PN3XJ0+etPp727ZtKC4u9uh3+IP169fjpZdewvHjx6VtzZs3x5QpUzBw4EDNn8NzWx9bt261c3jkWCwW/P3333j77beRlZVl9Rr72nf4qq/9Inri4+NVLeyEhASr7XFxcYoxftv9HFFdXY3nn38e69atw+LFi9GnTx+H+2dmZiI+Pl7z5zvDbDZj586d6Nq1q+anOuIa7Gvf4a2+tv2s9PR0XHLJJR77fH+Ql5eHadOm2bkNJ06cwLRp07Bq1SqMGjXK4Wfw3HYNERVwRmJiIrp16waAfe1LPNXX5eXlmgwLv4iejIwMnD59GidPnpRcmn379qFly5ZISkqy2jczMxO//fab1ba9e/eiS5cumr7r1KlTePjhh1FdXY3c3FykpaU5fU9kZKRXTnRvfS6xh33tOzzd11VVVVZ/19TUBPVvaTabMXnyZIfhlUcffRSjRo3SdJw8t/XRpk0bzfvZ9iv72ne429da3+uXROb09HT06NEDzz33HEpLS3Ho0CEsWrQIOTk5dvsOHz4cBQUFWLduHWpra7Fu3ToUFBRgxIgRTr+npqYG9913HxITE/HBBx9oEjyEEP9i6+wGeyLzpk2bnIZXDh06hE2bNvmwVeFDdnY2UlNTYTAYFF83GAxIS0tDdna2j1tG/IHfpqwvWLAAtbW1uPrqqzF69GhkZ2dLU8m7d++OTz75BEB9gvOrr76KxYsXo2fPnli0aBEWLlyICy+80Ol35Ofn47fffsOPP/6Iyy+/HN27d5f+O3z4sFePjxDiGrYiJ9inrB85csSj+xF9REZGYv78+YqvCSE0b948Ojphgl/CWwCQkpKCBQsWKL62bds2q7+zs7M1qfDZs2db/X3ttdfizz//dL2RhBCfI0ROXFwcKioqgt7padWqlUf3I/oxGo3Izc3FLbfcgurqaml7amoq5s2bB6PR6MfWEV/CZSgIIQGFED2NGze2+jtYYXglMDAajejYsSOA+ghCfn4+9u/fT8ETZlD0EEICCiFykpOTrf4OVhheCRzKysoA1LuI/fv3Z5+HIRQ9hJCAwWKxSOEs4fQEe3gLOB9eadq0qdX21NRU5Obm0m3wEUL0iP+T8MNvOT2EEGKLPN8iVMJbAqPRiLNnz+Luu+8GAKxevdqqCjDxPqWlpQAgFbcl4QedHkJIwCAXOCK8FQpOj0Au6i677DIKHh9SV1cnOTwUPeELRQ8hJGAQAsdgMEjL0YSK0wNYC7hQEnPBgFzolJeXKxaLJKEPRQ8hJGAQAqdBgwbSmnsUPcQTiNAWUF8lW+66kfCBoocQEjDIa/QI0RNK4kAu4ELpuIIBuegBGOIKVyh6CCEBgxACDRo0QIMGDQCErtMTSscVDNjO2KLoCU8oegghAYNSeCuUHBE6Pf6DTg8BKHoIIQGEPLwV6k4PRY9vsRU9arV6zGYzNmzYgC+++AIbNmyA2Wz2RfOIj2CdHkJIwCB3eoToCSVxQNHjP7Q4PSaTCRMnTsTff/8tbUtNTcX8+fNZQDJEoNNDCAkY5Dk9oTh7S34soXRcwYAz0WMymZCTk2MleACgqKgIOTk5MJlMXm8j8T4UPYSQgIHhLeItHIkes9mMiRMnKtbuEdsmTZrEUFcIQNFDCAkYQj2RmaLHf9jm8Mj/3rRpk53DI8diseDQoUPYtGmT19pHfANFDyEkYAj1KeucveU/HDk9R44c0fQZWvcjgQtFDyEkYFAKb4WSOGCdHv/hSPS0atVK02do3Y8ELhQ9hJCAIdSXoaDT4z8ciZ7s7GykpqbCYDAovtdgMCAtLQ3Z2dlebSPxPhQ9hJCAQSm8FUrigDk9/sNRnZ7IyEjMnz9f8X1CCM2bNw+RkZHeayDxCRQ9hJCAIdSdHooe/yFET+PGjQHYT1k3Go3Izc2VzjtBamoqcnNzWacnRKDoIYQEDEo5PVVVVYpTiYMRhrf8h3B2mjdvDkC5OKHRaLQKYXXt2hX79++n4AkhKHoIIQGDktMj3x7sMJHZfwinx5HoAazDXgcPHkREBIfJUELXr3n77bdj9erVfEIhhHgFpZweIDQEgtlsRnV1tfQ376O+xVb0qK29de7cOenfZ86cwcGDB73fOOIzdIme/v37Y+nSpejbty+mT5+On3/+2VvtIoSEIfLwVlRUlPSUHQoCoaqqyurvUDimYEKr0yP2E+fejh07fNA64it0iZ57770Xn376Kd577z3ExcVhwoQJGDJkCJYsWYLjx497q42EkDBBHt4yGAwhlcxsK3IoenyLVtEjnJ4OHToAoOgJNVwKVnbu3BlPPvkkZs2ahfj4eMyZMwfXXHMNJkyYgMOHD3u6jYSQMEEe3pL/PxREj+0xhMIxBRN6nZ5LL70UAEVPqKFb9Pzyyy+YOXMmsrOz8eSTT6Jnz55Ys2YNNm7ciEaNGuGhhx7yRjsJIWGAPLwl/38ouCJ0evxHTU2NlE/lKKfHbDZLv0u3bt0AUPSEGlF6dh4yZAj+/vtv9O3bF8888wwGDhyIqKjzH3HHHXfglltu8XgjCSHhgTy8Jf9/KLgiFD3+Qy5wHDk98gKGwunZt28fSktLkZiY6OVWEl+gS/QYjUaMGjUKzZo1U3y9bdu22LBhgyfaRQgJQ2zDW6Hk9NgKt1A4pmBBiJno6GgkJycDcCx6oqKi0KJFC7Ro0QLHjh3Dr7/+ij59+visvcR76ApvPfDAA6qCBwBiYmKohgkhLhMOTk8oJWcHC0LMJCYmIj4+HoCy6BFJzElJSTAYDLjkkksAMMQVSrDqEiEkYLDN6Qml9bfEMTRp0gRA/RT2uro6fzYpbFASPWVlZXaVvuX7AaDoCUEoegghAYOt0xNKrog4BrH2k3wb8S5yMZOQkAAAqKursyoWCVg7PQBncIUiFD2EkIAhlKesi2OTi55QcLCCAZHILHd6APsQlxBHQhgJp+eXX36hKxci6BI9AwcOxCuvvIKioiJvtYcQEqZYLBapanEoTlkXwi0xMVGa9RoKxxUMyJ2e6Ohoqf9tRY+t09OxY0fExMSgtLQU+/fv92GLibfQJXoef/xx/Prrrxg8eDDuuusufPrpp3al1QkhxBXk95JQdnri4uJCKmwXDNg6OPK8HqX9RE5PdHQ0Lr74YgDAK6+8gg0bNsBsNvukzcQ76BI9Q4YMweuvv46NGzeiX79+eO+995CdnY1nnnkGO3fu9FYbCSFhgNz1sBU9oeCIyEN3oeRgBQO2YkaIHzWnR+yXl5eH3bt3AwDmzZuHAQMGID09HSaTySftJp7HpZyepk2bYsSIETAajWjTpg0+/vhjPPjggzAajfjjjz883UZCSBggXI/IyEhER0cDCM1EZrnTQ9HjG2xFj9q0dbFfUlIS1q9fj9GjR9vtU1RUhJycHAqfIEWX6Kmursbnn3+Ohx56CFdddRVWrVqFUaNG4dtvv8V3332H/v3745FHHvFWWwkhIYztzC35v0NB9MidnlBysIIBvaInLi4OL730kt2UdgDStkmTJjHUFYToqsh8xRVXIDIyEkOHDsXKlSvRuXNnq9evv/56rF692pPtI4SECbYzt4DQSmRmTo//kM/eAtRzekR4q6SkBMePH1f9PIvFgkOHDmHTpk3o37+/F1pMvIUu0TNjxgwMGjQIMTExiq936NAB69ev90jDCCHhhW1hQiC0nB6Gt/yH1pwesV9NTY2mzz1y5Iinmkh8hC7Rc/3112Pz5s1Ys2YNTpw4gdatWyMnJ0eqZUAIIa6iFN4KJXHARGb/oTZ7Sy2RuUWLFpo+t1WrVp5qIvERunJ6Vq1ahfvvvx/V1dW46KKLcO7cOdx+++34+uuvvdU+QkiYoBTeCiWnRx7eYk6Pb9Gb09O9e3c0b94cBoNB8fMMBgPS0tKQnZ3trSYTL6HL6XnjjTfw+uuv48orr5S2bdy4ES+++CKuueYajzeOEBI+OEpkDgVxoBTeCgUxFwyoiR61nJ6GDRtiypQpmDZtGgwGg1VCsxBC8+bNQ2RkpNfbTjyLLqenuLgYffr0sdqWnZ2NEydOeLRRhJDwQymnJ5TEAcNb/kNvTk9iYiIGDhyIVatWoU2bNlb7pKamIjc3F0aj0dvNJl5Al+jJzs7G+++/b7Xts88+wxVXXOHRRhFCwo9Qn7LORGb/oTZ7y1lxwlGjRqGwsBB33nknAGDYsGHYv38/BU8Qoyu8ZTabMXv2bOTl5aFt27Y4duwYduzYgYsuugh33HGHtN97773n8YYSQkKbcJmyTqfH97hSnFD8NpGRkcjKysK7776LmJgYhrSCHF2i56KLLsJFF10k/Z2RkYG+fft6vFGEkPAj1KesM5HZf2hZe8tisVg5PfLfpmnTpgDqUzxIcKNL9MirLRcXF6NRo0bSarWEEOIOTGQm3sBisWjK6amqqpIqLCclJVnlqqakpACg6AkFdOX01NTU4LnnnkP37t3Rt29f9OjRA//+979RXV3trfYRQsIER+GtUBAHDG/5h8rKStTV1QFwHN4Swgg4L4oEwuk5efKkV9tKvI8u0bNo0SJs2bIF8+bNw9q1azFv3jzs2LED8+bN81LzCCHhQjiFtyh6fIdczAixoyR6RGgrPj7eLm9HHt5SWo+LBA+6YlOffvop3n77baSlpQEA2rdvj/bt2+PWW2/F448/7pUGEkLCA2cVmS0Wi2qxuGBALupCKWwX6Ii8HbmYEU6OPKfHNgQmR4S3qqurUVpaiqSkJK+2mXgPXU7PmTNn7Mput2rVKiSewggh/sVRRea6ujrU1tb6pV2eQim8xXun91ESM46cHiVBEx8fj9jYWADM6wl2dImejh074sMPP7Ta9uGHHyIzM9OjjSKEhB+OnB4guF2R2tpaKUmW4S3fYjtzC3Cc06Pk9BgMBiYzhwi6wluTJk3CPffcg08++QRpaWk4ePAg9u7di6VLl3qrfYSQMEEpp0c8XYvXGzZs6PN2eQK5uKHo8S16nR4l0QPU5/UUFRUxmTnI0eX0ZGVlYc2aNejbty8SEhJwzTXXYO3atbjsssu81T5CSJig5PQYDAZJ+ASzQJC3PTY2ljk9PkRJ9DjK6VHL16HTExrocnqMRiPee+89TJgwwVvtIYSEKUo5PUC9M1JVVRXU+S+i7bGxsYiIiGBOjw9x5vSIBHktTg/AaevBji6n5/jx495qByEkzFEKbwGhMW3dVtAxvOU7bNfdAs6Lnrq6OqnOnDOnh1WZQwNdTs/VV1+NO+64A4MHD0bz5s2tpo+OHDnS020jRMJsNmPTpk04cuQIWrVqhezsbK6BE2IohbeA0BAI8ho98v8H8zEFC44SmYF6tyc2NtZhIjNwPrxFpye40SV6Nm3aBABYuXKl1XaDwUDRQ7yGyWTCxIkT8ffff0vbUlNTMX/+fK52HEKohbdCwemxdbGY0+M7lMRMdHQ0oqOjUVNTg7KyMjRu3NjhlHWATk+ooEv0rF+/XnG7OFkI8TQmkwk5OTl2VVCLioqQk5OD3NxcCp8QQS28FQquiFp4q7KyMuiLLgY6ag5OfHw8zpw5I83g0ur0UPQEN7pyenr16qW4fcCAAR5pDCFyzGYzJk6cqFj2XWybNGmSVP+EBDdq4a1QdHrkwq6qqsovbQoXHIke4Py0dSYyhwdOnZ4DBw7gqaeeklaqveOOO6xeLy0tDdraGSSw2bRpk1VIyxaLxYJDhw5h06ZN6N+/v+8apgLzjtwjlMNbajk94jXbYyaeQ6vo4ZT18MCp6Gnbti2uvfZalJSU4Oeff7Zze2JiYjBw4ECvNZCEL0eOHPHoft6EeUfuE07hraioKERERKCurg4VFRVo3LixP5sX0ijN3gLsa/XQ6QkPNOX03HrrrQDqb+JMWCa+wGw249ixY5r2tV0Pztcw78gzhFN4y2AwIC4uDmVlZUEt5oIBpdlbgH6nR4ieiooKlJeXW80AI8GDrpyekSNH4pdffsGaNWuwevVqq//0UlxcjLFjxyIrKwu9e/fGrFmzVBcU3LhxI4YNG4Zu3brhuuuuQ35+vuJ+M2fOxBNPPGG1rby8HE8++SR69+6NHj164PHHH7eqwkkCD5PJhPT0dEyePNnhfgaDAWlpacjOzvZRy+xh3pFnkNdLCYcp6/J/B7OYCwY8ldPTsGFDREXV+wQMcQUvukTPyy+/jH/84x+YM2cOFixYIP23cOFC3V88adIkxMfHY9OmTcjNzcUPP/yAd955x26/wsJCjB8/HhMnTsTWrVsxfvx4TJo0ycoFKCkpwZQpU7Bs2TK79z/77LM4cuQIvvzyS3z11Vc4cuQIXnrpJd3tJb5BuCaOcnkASLNd5s2b59e8GT15R0Qd+cAfik6PUr5SKIi5YMBTOT0Gg4HT1kMAXaJnzZo1eP311/Htt99i/fr10n///e9/dX3pgQMHUFBQgKlTpyIuLg5paWkYO3Ysli9fbrdvXl4esrKyMGjQIERFReH6669Hz549pVpBZWVlGDJkCBo2bIjBgwdbvbeiogKffvopJkyYgOTkZDRt2hRTpkyByWTijSYAceSa2JKamhoQYaNgyjsKZLSInmC+ZpXylSh6fIOa6NGb0wMwmTkU0FWnp7y8HFdddZXbX7pnzx4kJyejRYsW0rb27dvj8OHDOHv2rNVssL179yIzM9Pq/R06dMCuXbsA1K9l89lnnyElJcUutHXgwAHU1NRYvb99+/aorKxEYWEhLrroIsX2mc1mj4YjxGcxxOGYDRs2OHV4AGDEiBFYtWoVIiMj7frU133dvHlzzfuF2u/vyb4WA09UVBQMBoPVZ4oFR8vLy4O2D8XxxcbGSscgxFxpaamm4+J9xDWE6ImLi7PqOyE6S0tLUV1dLTk+8fHxqn3dpEkTAPVLMvF38AyeOq+1vl+X6Onfvz8+/fRTDB8+3KVGCcrKylRnaJSXl1uJHqV9GzRoIJ2gUVFRkvq2RZzs8oQz8VmO8np2796t9VB0sXPnTq98bqiwefNmTftVVFQ47Utf9XVSUhKaN2/ucF26Fi1aICkpCdu3b/dJm3yNJ/paiN2YmBi7fjpz5oy0j6M+NJvN2LZtG06ePImUlBR07949YEoGHDp0CABw9uxZ6Rjq6uoAAH/88Ydm8QzwPqIX4eAcPHjQKm9UjAH79++3uvfs27cPRUVFAOz7WuT07Nixw+5hnLiHr85rXaKnqqoKTzzxBF5//XU7ofHee+9p/pz4+Hg7S1f8bZthHxcXZxfLr6ystNtP7XvEZ4v9xfc4sjAzMzM9mplvNpuxc+dOdO3aNWBuwoHI6dOnNe3XsmVLdOvWTfE1f/T1q6++itGjRwOAVWhO5B298sor6NGjh0/a4ks82dfR0dEA6q9/2982PT0dQP01q/a75+XlYfLkyXYlA+bOnYtRo0a51TZPIPJE2rZtKx2DyA9p1aqV6nHJ4X1EP2azWRo/evbsiWbNmkmvXXDBBQDqf5sLL7wQABAREYHevXujrq5Osa/bt2+P/Px8NGjQQNNvRpzjqfO6vLxck2GhS/RkZmZ6RN1mZGTg9OnT0hMZUK+uW7ZsaZdElpmZid9++81q2969e9GlSxen33PhhRciOjoae/fuxaWXXip9T3R0tHQjVSIyMtIrNxVvfW6o0L9/f6SmpqKoqMhhXk+LFi2c9qMv+1pMSx8/fjwOHz4sbW/VqhUWLlzo97wjb+OJvq6pqQFQ7+LafpZ4AKmqqlL8HpPJhNGjRyuWDBg9enRA5H6JgTc+Pl46BmfHpQbvI9oREQEAaNSokVW/ibGmoqJCehhOSkpCVFSUFCqx7WsxXpWUlPA38DDuntda36tL9DzyyCMuNcaW9PR09OjRA8899xxmzJiBkpISLFq0CDk5OXb7Dh8+HG+//TbWrVuHa6+9Fl999RUKCgowffp0p98TFxeH6667Di+99BLmz58PAHjppZcwdOhQVkANQCIjIzF//nzF88BgMEiDmpjaHEgYjUb06NHDSky/8847uOaaa/zXqCBCrRoz4Djh11nJAIPBgEmTJmHEiBF+HaSUEplDIUE70BEpDhEREXbnlnz2lpYkZoCJzKGArtlbALBq1SoMGzYMvXv3xuHDhzFhwgSX6t4sWLAAtbW1uPrqqzF69GhkZ2dj7NixAIDu3bvjk08+AVBvJ7766qtYvHgxevbsiUWLFmHhwoWSHemMp59+Gunp6Rg2bBiGDBmC1NRUPPXUU7rbS3yD0WhEbm6uXR5Xamoq/vGPfwAI3KnL8qdKAHYOJVFHrRoz4HjKerCUDHBUp4eix3vIZ27ZLuoqFz3OpqsLWJU5+NHl9Lzzzjv44IMPcO+99+LFF19EQkICjh07hueffx4zZ87U9cUpKSlYsGCB4mvbtm2z+js7O1tTAbrZs2fbbUtMTMSzzz6LZ599Vlf7iP8wGo248sor8c0332Ds2LG46aabkJ2djTlz5mDlypUBK3rE06KACafaUavGLN+m9LsHS8kAR3V6AvV8DgUcrZxOpyc80eX0fPDBB1i0aBFGjx6NiIgINGrUCAsXLlStkEyIq4gZO0OGDEH//v0RGRkZ8E/GtqLnl19+8VNLgg9HosfR7651CRJ/L1XCOj3+QW3dLcC6Tg+dnvBBl+gpKSmRwkoiht60aVPV5SMIcRUxkys5OVnaFuiVeYXoETNEfv31V9by0IhS+Efg6HfPzs5GamqqXehCEAhLlQDKx8ecHu+jtu4WQKcnXNElejp16iRVQhY3mXXr1iEjI8PzLSNhTTCLnksvvRTx8fGorKzE3r17/dyq4MBVp0ckvzvC30uVAFyGwl9oDW/pdXrOnTsXkBMqiHN0iZ5p06bh5Zdfxs0334zy8nLcf//9mDFjBqZOneqt9pEwxGKxBKXoOXv2LID6qbGipALzerThak4PcD753XZgi4qKwqpVq/w+XR1wHN4K1PM5FPB0Tk9ycjIiIuqHTbo9wYku0dO5c2d89tlnGDRoEG666SZkZWVhzZo1Ug0cQjxBZWWlVLdFLnoC/clY3DiTkpLQtWtXAMzr0YqrU9YFRqNRqhRvNBqRkJCA2tpa7Nq1Cx988AE2bNjg11AjnR7/4Ej0KOX0OBM9ERER0lIUFD3Bia7ZW0D9GkL33XefN9pCCIDzoa2IiAirm1CgOz1y0dOhQwcAFD1acXXKupwTJ04AqF+bzWKxIC8vD//+97+l11NTUzF//ny/OD+s0+MfPB3eAupDXCdPnmQyc5Ciu04PId5GHtqSJ6gGk+i55JJLAFD0aMWd8Jbg2LFjAOoXNF69erXd60VFRcjJyYHJZHKztfphnR7/4Gj2livhLYDJzMEORQ8JOIToadSokdX2QB8kxI2zYcOGUnhr//79dlPZiT1awlvV1dUOQ1RC9CxZskS1QjMATJo0yaehLovFwjo9fkLL7K26ujpJwGh1egBOWw9WKHpIwKGUxAwEl9PTtGlTtG7dGkD91HVSj9lsxoYNG+zybLSEt4D6darUPleEt4T4UcIfFZrls3zo9PgWLeEt4Pw5Q6cn9NEteoS6ra6uxooVK/D55597vFEkvAkF0QOAIS4bTCYT0tPTMWDAAIwZMwYDBgxAeno6TCaTpvAWoC4QiouLUVdXp7ktvqzQLG8zc3p8iyPREx0djejoaADnRQ+dntBHl+j56KOPMGjQIADA//3f/+HVV1/FrFmzsGjRIq80joQnFD2hh8lkQk5Ojt06WSLPZs+ePQCURU9UVBSiournXKj99mLQatiwoab2+LJCsxA1BoNBGmQBOj2+wNmsLOH2HD9+3OF+coToodMTnOgSPe+//z5effVVmM1mmEwmLFy4EB988AFWrVrlrfaRMEQsQWEresQgUVtbG5BVwEWdHiF6RF5PuNfqcbYSOgD8/PPPAJTDW4BzwStET2pqasBVaJaH7uTtoujxPs5Ej8j1ESUytDg9DG8FN7pEz5EjR3DllVdix44diIqKwmWXXYa0tDTpZk+IJ3Dm9ACB6faoOT0///wzVqxY4fdaMe6gloujBS0roTtKZAacCwQhelq2bClVaLYVPuJvX1doVltig4nM3sfR7C3AOq/H0X5yGN4KbnSJnkaNGuHAgQP48ssv0atXLwDA5s2bpbWGCPEEoSJ6du3aBaD+xnvrrbda5bAEE2q5OHl5eZreryd/Rk30aHV6WrRoIVVobtOmjdU+zZo1Q25urs/r9KjlK6kJOXcEJrHG0ewtwDXRQ6cnuNEleu6++24MGzYMH3zwAe677z789NNPePDBB/Hggw96q30kDFGbsh4REYGYmBgAgRcSsFgsVqLHZDLh5ptvttvPn7ViXMFRLs7o0aOxfv16p5+hJ3/GXaenRYsWAOqrMhcWFiI/Px/dunUDAPz73//2S2FCNadHnsgswnyOkr2JPsxms+TG/Pnnn4ri0Vb0MJHZcwSqeNclesaMGYPPPvsMX375JS699FJceOGFWL58eUCsbUNCBzWnBwjcZOaqqiopzyghIcFpDouva8W4gpZcnDlz5jg9Di0roYsEX3dzeoToAeoXI+3fvz+uu+46AP7LrVIL3YljtVgsqK6udprsrdVZCwecDahCPIoyBg899JCieLR1gPQ4PadPn9aVWxioIsAbBLJ41z1l/cyZM2jVqhXOnTuHpUuXYsuWLQGZVEqCl2AUPfIChNu2bXOaw+LrWjGuoCUX59ixY06Pw9FK6EIIiYHEU06PHLE24Pbt2x2201uo1SCS/11WVuZUYE6ePDmkB0qtOBtQnYlH+cArd3oaNGggzRJ0ROPGjaV/nzp1yiNt9gb+Ell6+t8f6BI9r732Gu68804AwLPPPov8/Hzk5eXhhRde8ErjSHgSzKInISHBYXE8Ob6sFeMKWtt39OhRp/uIPBvb8IHIsxGDjSdyemwRomfnzp1evfGrDTJq4a2YmBhJ9G3YsMGpwPz777+xbds2L7U+OHA2oH700Ue6XFa56NHi8gD1JRTEvUlLXo8/RIC/nBYt7rC/XW5domft2rVYvnw5qqur8eWXX+Lll1/Gu+++i3Xr1nmrfSQMUZuyDgTuNF95Po/WHBZf1opxBa3ta9mypab9jEYjRo0aZbVt8uTJMBqNDisyA+6JnoyMDMTFxaGiogJ79+7V1Fa9OBpk1MJbBoNB2nbo0CFN3xPOeSRaBtRx48bpclnlokdLPo9AazKzP0SAP50WLe6wv11uXaLn+PHj6NSpE3766SckJSWhU6dOaNq0acANQMQxgR5bDkanR16jR0sOi69rxbiCluNo0aKFruMoKioCcH46f0FBAQDHC44CjsVuXV2dVFxOSfRERkZKNZN27Nihua1acTbIfP/99wCUBZ3YZpu0r4YYbMMRLQOqyOFxhnAx5Tk9Wp0eQHsys69FgL+dFq3usD9dbl2ip0WLFvjxxx+xevVqXH755QDq3Z+0tDSvNI54nkBIMHMkuiorK6UBMJhEj9zpkeewBEqtGFfQkovz2GOP6ToO4WjcdNNNAIAffvhBU50eR797SUmJlFfYvHlzxfc7yutx5yFAyyCzcuVKAI5FT+fOnZ0KzNTUVHTv3l1z20INTw6UwsV0JbwFnBc969atc3jO+FoEaBVZCxcu9IrwCQaXW5foGT9+PO677z5s2LABDz/8MH744Qc8+eSTmDx5srfaRzxIICSYORNdIrRlMBgU7eZgCG8B53NYbC/u1NRUv9SKcRVxHLGxsVbbU1NTsWrVKgwcOFDzZ4m8FAAYMWIEoqKicPToUezfv18SLWrhLUe/uwhtNW7cWCppYIsQPbZOj7sPAVoGGeFcOltB3pnAnDt3bsALZW8gROnvv/+uaf9mzZppdlldCW+ZTCZs2LABALBkyRKH54yvRYBW8TR58mSvPOwGhctt0UllZaWlsrLSYrFYLKWlpZZjx47p/YiApayszLJ161ZLWVmZRz+3trbWsnXrVkttba1HP1dvG1JTUy0AFP8zGAyWtLQ0r7bx448/thgMBsXvNhgMlo8//tiya9cuCwBLo0aNFD9jyJAhFgCWd955R/U4/dHXS5YssQCwDB061Gp7RUWFdJxr1qzx6zngDhkZGVa/2fHjx3X3dXFxsfT+iooKS48ePSwALG+99Za0Xe3ae/jhhy0ALE8//bTda+vXr7cAsHTq1En1u7/77jsLAEubNm2kbVrOR2esWLFC9Zqy/e/hhx+2e3+XLl0sACxff/211KbExESr96WlpVk+/vjjgLiP+JqPP/7Y4X1L6R720Ucfaf5dX3zxRel1o9EobVfra73njLjvKr3HG/fd/Px8zeejnvNcD670kSfOa63jt+4p63v27MHzzz+P+++/H7NmzcLBgwf1fgTxA/5OMNMaaxaJgUqhLSDww1u2C142aNBAckkuvfTSoHxSr6urw4EDBwCcfxreunWr7s8Roa1mzZqhQYMG6NOnDwBIT82A85wepd/dURKzQOQQFRUVobi42GO5D+4WXrR1sIxGI6699lrp9UsvvRT79+8PGmfQk6g500rIw8Y5OTnIzc21uxaVXFZ5To8zp8eVc8bXoW5nTouWNruL0WjEtGnT7LYHisutS/R89913GDNmDE6fPo2OHTuitLQUd999N7755htvtY94CH8nmGkVXd999x0AddETqOsV2Ya35Iht8lo+wcThw4dRXV2NyMhIDBs2DEB9Lo5exO+fmpoKAJLoyc/PB1A/hTsiQvmWJK9ebIsW0ZOUlIR27doBqA9xeeohQIudL3JFHOX0yI9LPpPr5MmTQSmU3cWRwFDCdkA1Go244447AADDhw9Hfn6+onjUk9Pj6jkjQsS2sxxbtGjhcRHgKA9PCW897Nqe6ytXrgwY8a5L9CxYsAAvvPAC5s2bhylTpmDBggV48cUXsWjRIm+1j3gIfyeYaRVTYnaPM6cn0HN65AS76Nm/fz8AoG3btujbty+A+jX39CIGczHxQYgesV3N5ZG/5qrTA1gnM3vqIUBLsrc4TkeiR35ccve8qKhIWjQznHAmMOQ89thjigOqmFk1YMAA9O/fX1E86snpceecMRqNWLt2rdW21157TZMI0JtoL0SW7RIbetvsDrb1pNq1axcw4l2X6Nm/fz8GDx5stW3w4MEoLCz0ZJuIF/B3gplWMSWK1AVreCsURc9ff/0FALjwwgulWZtbtmxBXV2drs8R4kY4Pe3bt5dmwQCORY+WRGZnokeswbVjxw6PPgQYjUZ89NFHdteWcB/EE77S8dmK+MrKSul4xGveqi0UyOgZhJOTkxUHVNGPajP6AH1Oj7vnjO30dnFdOcLVRHuj0YirrrpKU3sdtdlVhOgRzq0oKREI6BI9ycnJ2L17t9W2Xbt2cZX1IEDLE6k3p1FrFV3iXAo20SOv02NLsIse4fS0a9cOXbp0QUJCAs6ePat5No1APLkLp8dgMEguCOBY9IhZWbt377Z72tXr9OzYsUM6H9XQ+xDQp08fq1DMuHHjJPfBUeFFWzEnhGFCQoLU3j179mhqQyihZxBWG1Ad1W4S6MnpcffB0bZSu7Pf1d3ZtiUlJQDqp9f78mH31KlTUg5gr169ANgfuz/RJXpuuukmPPzww/jwww/x3XffYcWKFRg3bhxycnK81T7iQYTtaTu4+CLBTKvoEuJBrVhbsExZl+NP0eOJQpTiibRdu3aIiopCz549AdS7PXqwDW8BsBI9NTU1qotHPvPMM9J32j7t6hU9v//+O8xmM+677z7F/Vx5CPjzzz+t/o6JiZHeq7YMhXyb2EeEti644AJkZGQACE/Ro0VgiAcjtQFViB5POT3uJiWLdorFdW0NBDmeSLQX64JNmjTJ5Ta7gqiFdeGFFyIzMxNAEDs9999/P4xGIxYvXoyHH34Y7733Hm677Tbce++93mof8TBGoxGdO3eW/h4zZozPEsyMRiPefPNNu+1y0eWoGjMQuE5PIIoeTxWilIe3AEghLr15PbbhLaBe6AiOHDmiunikeGoVyJ92tYqetm3bomHDhqipqcHLL78sFQ0Ug5DAlYeAXbt2Wf0tD/k7Krxom9MjFz1iwAhH0aNFYNx9990AlAdUs9kshZMciR55/akDBw5ozpdp3bq11XYt54xoZ1ZWFgDHv6snEu2F6Bk1ahRyc3PRpk0b3W12BRHa6t69u3RNBq3Ts3TpUtx7773Iz8/Hzp078cUXX+Dee+9VnXFBAhP5ejFVVVU+TTCTCy4AeOWVV6xEF0WPZ/BkIUp5eAtwTfRYZIUJhdNjMpnw7LPP2u2rd/FIseCpM9GTl5cnnTdPPvkk/vjjDwDA1KlTAdSfc2qzfJwhnJ5OnToBgGTvA+qrrAP2OT10es7jrMDn0KFDASgPqMXFxbBYLDAYDFZ5Y3JMJhOuu+466e8ZM2ZozpcpLCyU7ptaZyaJdorJAIcOHVJ1rN1NtK+rq5MeFJo0aSK1ecqUKQCA3r17e+1hVy56hOAMWqfnjTfesKvMSoIP+fo0tra8txEDqKBFixZWosuZ6An0Keu2tUEA34seT66/U1FRgcOHDwM47/T07t0bAPDHH39oPqbi4mLpN2vTpo1HF48UbpEj0SNEYHV1td1rzz//PID6c0ptlo8zhNMjJnooOT16wltt27aVRI+jMEioYzQa8e233wKod+TkolT83koDqhAYTZs2lSZHyBHngxDMAiG48/LyHLYrKipKWgetY8eOms4Z0aaLLroIjRs3BqCepO5u0vTZs2eliQbiuyIjI3HFFVcAqE8w9tbDbkg5PdnZ2ViyZElAqTaij4qKCqspsHv27NE9C0dgmy9SXV3tNH/Edqaf7aDmaIV1gFPWteDJQpTyooTiibl58+Zo3749AODXX3/V1CbRnubNmyM2Ntaji0cC9WJTLRFaa80X+bpvehEPD0L0nDp1Svq9HS2mqiWn5/jx41KuWzgi7gnNmjWzEqXCRSguLrYKkwKOk5i1CO7Jkyc7fSho0qQJANiFXtWQh2GduXhaigw2a9YMRUVFivdaEdqKj4+3Ou+EANLaZr2Ul5dLDwAh4fT89NNPmDdvHvr164eLLroIF110ETp16oSLLrrIW+0jHkbEuaOiohAdHY2qqiqrYmhaUcoXiY+Pd5o/IpwecTGLujwChrfcx5OFKOX5PPIbsHB7xDpEzgYI2yRmT9cFceTyaBFYAnH+6aG8vFwShz179pQGFrFNi9OjlNPTsGFDadAI1xAXcH6AFv0qaNKkiZRaYTsd3FESs5bz4e+//7arNWOLaI8QGM5QEj1qLp6WIoMnTpzAbbfdpnivFW0Swsy2zd4SPTt37kRdXR2aN2+OVq1aBb/oefHFF/Hee+/h3Xfflf4Tf5PgQNwcmjVrhg4dOgDQH+JSyxexHfiU8keE09OlSxcA9k5PMIoes9ksuWeBIHo8WYPGNp8HqP/9161bB6C+mvKgQYOc5kLYJjFrbaOzxSOF++RI9OgRWGqDgaNZcEKQNGnSBCkpKUhPTwdgL3qc1emxWCxWogdA2Of1AOoDeGRkpFTiwjZ84kj0aD0fbIWULaI9WkRPXV2d5Fy2aNFCU5K60WjESy+9pKmttvdaLaJHa7VrPchDWwaDQbouT5w44XJEwdPoEj29evVCYWEh2rZti169euHIkSM4cOCANBefBD7iwktJSZEuPD05A3rKwyvlj4hBVCTzqTk9wTRlvbS0VPp3IIgeTxailE9XB84LXltHxFmCtG0Ss9Y2imrvajN4Ro4cCcCx6NFT80XJ6XE2C07Y+R07dgRQn48DnBf4Wuv0nDx5EpWVlTAYDNJMm3CewSVQc3oAqDoJjkSP1vNB5OyooUf0lJSUoLa2VmqTVjEr8pF69uyJ999/X7Umnu291pnoqa6uRnl5udN260UuegBI7ZW3yd/oXobitddekwacxMREvP7664rTkElgIkRPs2bNXBI9esrDA9b5I/KFK5VEj/xCDCanR4iZqKgoxUR/X4seTxailIe33EmQtg1vaa15IhaPtJ1u27p1a6uZPY5EjxaBJaat2zo9WmbB2c7cUnN6nIke4fK0atVKKsYYqE6PJ+o/aUVtAAegmszsqBqzlvMhNTVVGrjV0CN6RHsaN26MmJgYzfdesRiv0WhEmzZtHOa5ye+1an2WmJgoCSlvhLhsRU90dLTUhkBJZtYlenJzc/Hee+9JF/XVV1+Nt99+G8uXL/dG24gXkIe3xJOpnvCWq7kYR44cwZEjR6SFK4U7WFRUJA2YImERUJ4FBegXPb64OcvzeZRupP6Ysm40GrFs2TK77Xprc8jDW1oTpJ955hm7vlaq0SOmJDurHyKm2+bn50uDnFi3SEuNHi0CS1wLcqdHq8gTlamVnB6z2SzNGHOWyGwb2gIQkDO4PFX/SStanB618JbSeaHlfJg7d67ThwI9+TG2Ikz8rseOHVNNUq+rq8PGjRsBAP3799eVq6cmegwGg9fyempra7Fz504AsBKMgZbXo0v0lJaW2lmDrVq18opNRryDu+EtV9doadWqlWT3p6WlSTf2qqoqqW6QGHCSkpIUp5kC+qase/Lm7Eg8OUpilm/3dXFC2wkG3bp101Wbw2KxWDk9Wm+6M2fOtOtr2/CWQC5oVqxYoVonJzIyEv3798cNN9wAAPjf//4HQHs1ZmcCSwgW+UCgVeT9/PPPAJSdnqqqKml/Z4nMjkSPP50e+bk/Y8YMj9V/0oorTo+zaszOzodRo0Y5bZcrTo9or5Yk9V9//RWnTp1CQkICevTooStXz1GfeUP0mM1mLFu2DJWVlYiLi5OuAQABN21dl+jp3Lkz3njjDattb731lnSxk8BH7vQI0XPgwAHNzomWqZRy5PkjwjVIT09HTEyMdNGLEJez6eqA9inreXl5Hrs5OxNPjmr0AP4TPcLBE/1ZWFioq5CofNp1enq6bsEr+vrjjz9WFT3AeUFzyy23OK2T069fPwCQnoC1rK8kcCSwxEAgd3q0ijwhVpScHvl56iyRWUn0iMkGp06d8ktOhO25//TTT3uk/pMe3HF6HFVj1iq41dAjepTOU2f5Wvn5+QDqUwGio6N15eppET2eOp/EOXLPPfcAqD+X27VrJ90fg9rpeeKJJ/Duu++if//+uPnmm9G/f38sW7YMTz75pLfaRzyM3Olp3rw5GjVqBIvFgn379ml6v5aplLaI/BHh9Igid+IpSwyIzmZuAdrCW2azGZMnT/bIzVlLTocep8cbMybUEA7e0KFDER0djdOnT9vVSXKEcHlat26NuLg43YJXHOuECRNQVVUFg8FgV75fL2Ll6K1bt6KsrEyz0yNQE1jinJM//WoVeVVVVYiKipJqF4mn3OPHj0sDS1RUlKJ76Sy8lZCQIF0nvnZ71M59NfTUf9KDN5wegR7BbYs7Tg/g3MUT+Tz9+/eX2qp17S9fOT1a7o9B7/R89dVXmDRpEgYOHIjHHnsMn3/+OZ2eIELu9BgMBulpQ09ej7CGbcWJ7Q2jcePGVrkZcqcHOJ/fIZweT4mebdu2eaQ4n9acDuFQORM9ZrPZpwnYQvR07dpVKhEgQjFaEL+XEKmObrpqWCwWqaJzixYtpARdV0lPT8cFF1yA2tpa/PDDD7pFjxpKTo+WJ2sxO6Vdu3ZSMnRycrL0m4vrSim0Jd+uJnqA84OjWvVeb6BnlqYtnq7BpNfpKSsrk0pIOBM97uCK6JG3x1G+ljyfZ8CAAdJ2rWt/ORI9eosqqqH1/ihmwQWl0wPUTyUeOXIkHnjgAQwbNkz1Rk8CE7nTA5y35PUmShqNRkybNg1A/eCQn5+P8vJy5OfnY/jw4dI+cqtYq9OjNl0dOD9ImM1muyqsAmf1NQTObs5aczrEjAW1a0G+erMvQ1xiwM3MzMRll10GAE4Lrsmxna4OqOdCaEGexOwOwu1Zt26dlE/oruhRcnq0zIIbMWIEAFg9+BkMBknYi+nszkRPZWWlNNtLTfT40unRO0tTjiOHzJWJBXqdHvHvuLg4pyunu4Mricxaw1s7d+5ESUkJEhMTpWtXYDQaceDAAWmF+HfffdcuLOcLp0fr/VEkagel00OCH7nTA8ClZGaBGMC7deuG/v37IyYmBv3798dtt90GANixY4fV/p50egB1t8dZfQ2Bs/CF1idWsX6PmuiJiIhAQkICAN+JHovFIv2mHTt2lG6c7jg9ApEL8c0330hxfC0o5fO4gsjr+eijjwDUh4BE/7qKktMDnBd5tg5V06ZNkZubK52P4uFBIPJ6hOhRWyJDbJeH6gLB6XHFrXFW/8nViQVa6/QId0Ee2tLqSLqCEBTnzp1TfQATKOX0KIlZIQrnzJkDALjyyislB1FOZGSkdP9s27atncsuX2zUFk+JHr3nSNA6PSR4qaurk2ZKCWHgSnhLIMI6ts6MmK64c+dO6WZQW1srTVu2dXr0iB55HRw10dO9e3eHroLW4nxaczpEroYj19PXycxHjx7FuXPnEBERgXbt2km/ibtOj0DkQjz44INOQ0Di2D0leoTTI54y3XV5AGWnR2A0GqU+EGKmf//+MBqNdjV6BHqdHjFgx8fH2w1U/nB6XJ2lqVb/SUvuhxI1NTXSNaM0gAvRU11dLd2PtObzuIv8PuVMQCg5PfIk9eLiYitRKMpNbN68WbVvWrZsCQB2i6ZaLBafJDJrPUfE/Z5OD/E5JSUlUilwd8NbACTb0nbWUrt27ZCUlISqqirppl9UVITa2lpER0dLF4sricwRERGS8FETPZGRkZg7d67ia3qK82mdLSHaG0iiR/ye6enpiI2NxSWXXIKIiAgcPXpU8xOafLq6GvK+Vuunbt26AfBceCsjI8Nq8IiNjXV7xpCa0yMQDumMGTMAAGvXrsXZs2ftqjELhDj6448/AKg7PbZiqG3btnb9KETPH3/8gS+++ELz4r7uoDdpHQBmz56NJk2a2LXJnaKW8t9D6b7QoEED6f4jBlVfiZ7IyEipTY4EhMViURQ98fHx0jWxZMkSRVF45swZVVGoJnrKy8ul2lDezOnRen+89tprAdDpIX5A5PM0atRIskzF08bJkyd1K381pyciIkIa6ISzIPJ55FasbXhLy5R1QNu09f79+yvOltFTnE/kdCjdrOXiydG6WwJfix7hQIjBOCEhQfq3lhBXbW2tlFir5PTIGTVqlGKeT3R0ND766COprzzl9OTl5VkVdPvjjz/cLo7nyOmRl9C/9tpr0alTJ1RWVmLZsmWSe6nm9Ij3qTk9tmLINrQFQCr4Vl5ejn/9618YNGiQpsV93UFLPtN//vMfrFixAldffTUA4Omnn1Zsk9bcD6WJBaL/GjVqpPqQYjsl2lE1Zk+jJVR07tw56QHNtk3i/jtz5kyHSeNKolCIHlsHRfRZTEyMlPejt81a0Fr5XTzklpeXWy3Z4y8oesII23weoD7JVgxWet0eNacHOP90v337dgD2+TzAeafn9OnTKCsr0+T0ANpmcOXm5qK2thZdunSRFu1LTU3VVYcDAK655hrFG4dcPDmbsi5/zddOjwhfAtCczGw2m6X+i4qK0l0DZ/HixYiOjkZNTQ1atWpltwSFO4gwia3gdbc4nhgIzpw5Y7cwotwhbdq0qZSz9swzzwCoP/9tz1nh9AjURI/BYLAK2dqKHpPJhDFjxti9T8vivu4i8plsH2pSU1Px8ccf46mnnsItt9wirX9mez2KNq1Zs0bT9yk5kI7yeQS2U6L11G5yFy0zuES7bHPPTCYTfvzxRwCQHpyUUBOFak6PPLSl5MJ4csq6OEdsxwD5/TExMVE6/wPB7aHoCSNsZ24JXA1xqTk9AOxySGxnbgH1g4WYXVFUVORR0SNi4nfccQf+8Y9/AKi/OWhd6VckFD788MMoLy9HRkaGNMh16tTJSjw5K04I+N/pAaApmVnkFdxyyy0A6h0feaExR4g8nwceeAC33347gPonPeEYHTp0yK0wjDthEmeIc85isdgtCyCum+TkZKu1hMRDxNmzZ+2cFrm4B9TDW4C1IJKLHncX9/UERqMRw4YNAwDk5OTYFfAzm8144YUXHLZJ6zJFSjkijnJTBLZOj6/CW/J2ORI9SiJMiHdHYscWW1GoRfQo4enihPJZujfddJPdOWIwGFSLSPoDip4wQsnpAVyfwaVF9Gzfvh0Wi0XR6QGsQ1xapqwD6iutC6GyYsUKfP/99zAYDLj11lvRpk0bxMfHo7a2VspTcYQ8oVDcsE+ePCk9pZWUlFhZ7cHi9DhLZnY12VSJcePGAaifYSUG4VtuucWtMIw7YRJnxMbGSueV7ROw/LoxmUzSscmx7aOUlBQrMaPm9Ni+Jhc97izuq4YrU8ZFXpJSAT8tv8mJEydUVwcHHE8scMfpCRTRY5vP42oNJFtR6K7oKSkp8VixVFGL6/rrr1cs8qhWRNIfUPSEEWpOj4grf/3117qSIh2Fty6++GKrKsBKTg9gnczsjtMjhMqgQYPw8ssvA6iPaW/evNmqCKMzYac28J8+fRqPP/44gPqbmPy7A0301NTUSOJO7vQI0VNYWGh3k/a0i6JW+dmdMIyeBRddQS2ZWX7daO0jea0ewDXR487ivkq4MmW8rq5OEj2dO3fW/F223HzzzYrbnU0sCAWnx1b06BWzaqLQVdEjtpvNZo/l2Ii8TLXJCoG0FAVFTxih5PSYTCbMnj0bAFBQUKA5KdJisTh0emJiYqQqwNu2bdPl9OgVPWpCpaqqShpgtawor2XgFzdpEbIBzou/QBE9+/fvR21tLeLj460qtyYnJ0ui09bt8aSLIvpR7XMA18IwehZcdAW1ZGZx3RgMBl19JM/rcRTekr8mFz3uLO5ri6su3oEDB1BeXo6YmBhpmQ1n36WEcElt135zNrFAi+ixdRECLZHZtj16xKwjUSg/bvm15KzP4uLipLpTnlp0VJxXakVLA2kpCoqeMMLW6RE3QtsKxlqexquqqqQaPGq5LMJZKCgokJ4E1JyeAwcOSE8dzkSPvIqtFqt40qRJ0rRfR6JHy8AvvkdUzwUCz+mRV2K2HWTEb/LWW29ZuXqedFG8FYbSs+CiKzhzerQuoSH6SIvTYzabUVtbK/0tnt4B9xb3tf0OV1283377DUB9HpvSbEgtbWzSpAk+/PBDAMCzzz6LL7/8UkreNplMDicWaAlvyfNFzGazdD8LtERm0R49YtaRKBRLCZnNZqn+mrwtaqLHYDB4NJn53Llz0gMwnR4SUIibd7NmzdwOZ4iTXF58zhYxg+vTTz9FXV0dGjRoYHcjEqLn999/l7Y5y+mRT1nXOsCKY3IkevQ8gQnRY7FYAk70KOXzAPUDzDfffAMAWLFihZWr50kXxVthKD0LLrqCM6dHbx/JnR4l0SPCTfKQa8eOHaWHDT1rnTk6fndEqBA9F198seJ7tbTx1KlTKCwshMFgQGpqKq699lpcd911AIDPP//c4XHpdXpOnTplV4vMm7iSyKxVKH7zzTcOZ5tGR0dLxygPcWnpM08mM4sH2oYNG6reA+n0EK/hKFFRHt5y92lcvsimrZsgEK6CEDTp6el2F7p4MhA314SEBMWy63Lk4S2tA6cYdBzl9Oh5AhOip6qqSnpSDzTRI8/nEa6e7cykoqIi3HjjjdiwYYPDm6QeF8WbYSi1tb/01F9Sw5nTIyp9a3Wa5KGqo0ePWl2LWsNNasdrK2wcHb87IlRcl0r5PAKt67FZLBbcddddMJlMuOGGGwAAn332mcP36HV6hMBo2rSpojPlaVxxepyJd4PBgCVLluDqq692KuCV8nr0iB5POD3iHHZUfJROD/EKzhIV5eEtd5/GHSUxCy699FKri9o2nwc47/QIe9ZZaAuwFj1aB07hOh07dkwSbLZoCZ8IF0qIHrmIcbS4ob/CW4C28MZ//vMf1Ru3XhfF22EoeU2gFStW2E2RdRVnTk/z5s01O00mkwmTJ0+WXl+2bJl0Lep1WeVrnc2cORPffPONVKgQqL/OHB2/OyJUi+ixbaOjwRaoP7bBgwcDqA99OxoI9Tg9Z8+elXLtfJHPA2hzTJRyjDwl3l0VPZ6qygw4T2IGwCnrxPNoeXKUOz3uPo07SmIWJCUlWSU/RkdH24XLbC96LaJHntOjdYAdMmSIdCxqIS4tFUbvvvtuAOdnJwkRk5CQ4FAQ+NPpcWfFbED/jdjbYSjxHf3791ecRu0qzpyeZs2aaRqsxLVoO5iLa3HWrFm6XVZxvEOGDJEW9x0yZAiA+nPK0fG7KkKdzdyyJTIyEpGRkU6XZDh06BD27duHyy67DBaLxWGIS4vT06hRIynf6tdffwXgO9GjRTwoLUEBeEa8B5LT48jp45R14lG0PDlOnDgR5eXlAOqdHnefxoXT40j0mEwm6SkAqM/tsZ0Z1rx5cysb2lk+D2Cd06NngNUyg0sMakphuNzcXIwePRqAvdPjKLQlf93boufs2bOSOyeSt12d+qwlr0ANb4ahvIWa02M7AcDRYKXlWlQT1rY4+91E+OzQoUMOi25qXS7AVjgVFhaioqICsbGxijO3XGmzfD8R4lq7dq3qfloGcHnxO7Fkh69FjzyXSE5FRYV0zSslVrsr3t0VPZ7I6dET3iouLna6Ir23oegJAbTk54jXY2JikJSU5PbTuHB61MJbWpcLiIiIsJtW7QzbKetaB1itlacHDx4sDVBLly61GtREcqpYQDXQRI9Yibt58+ZSX7o69fnUqVPS07sreCsM5S3UnB6lUg9qg5WWa1HrQOPsd2vVqhUiIyNRU1PjNGwgrhHbhGpHIlQ+c0vrOaDHQR46dCgAYN26dVi2bJldDqLFYtHk9ACwEz2+mLkFnG9XXV2d4rUtnI2YmBhND3R6CSSnx5Hoadq0qZT7aTtb2NdQ9IQAep7kU1JSJFHjztO4o/CW3pwF+cWiN7wlMBqN0k0aqHeVbAdYkePiyOkBzvdnQkIC7r77bqtBrWXLloiJiYHZbEZRUZGmGj3y170pesxmM/Ly8gDU3/RF/7qyYrbAVZdI4I0wlLdQcnrKysok4a5lNpDW/lJbFwnQnvMUFRUlXbvyulFqGI1G9OzZU/r7wQcfdChCnc3cUkKPg3zw4EFERESgvLwcd9xxh10OorPVwuUIkSPCcb5yeuLi4qT7kZKYlYe2XLn+nGG76GhlZaXk6Psqp0eL6ImMjJSuH3/n9VD0hAB6nuRty8GLp/GpU6cCAHr37q3padxRIrPemWFy0aXH6bF1kYSgiIyMxJAhQ+wGWC3hLeB8SfXWrVvb3agiIiKkhTMPHDig2+kpLS3VvP6XHkQS+6xZswDUP/GKAUTP1GdbXHWJghGlp1/xVBobG+swUV2gtb9E8UZ3c55EiEuL6AHOh+qA+nPZ0XdoTWKWo9VBXrNmDUaPHm13LcidYPE7REVFWS3UqYQQOVVVVVZ/+wJHrom3CyXaOj2iDZGRkQ4nmXjS6dGSyAwETl4PRU8IIJ6u1DAYDJKyV3pajYyMxBVXXCHtq+Vm68jp0TszzFXRY7vgqGhTYmKi4uAuRM+ePXscCg/RLrUBTIS4XBE9gOMVlV1BSxK71mnFAndnWAUjSuEteRKzFsGo1emYPn26R3Ke9Ioe+YAjqqSr4YroAZw7yCNGjNDkBIu+d+SKCWxFhS9Fj6Np62pJzJ7CVvSINjRu3Nhhn3lK9FRWVkq/k7N7S6DM4KLoCQEiIyOlFcBtESf+iBEjANg7PYKmTZsCgFVlT0c4SmTWOzNMntNTXFzsdHkCNdEjBiu1J/L09HRER0ejoqIChw4dUv18udOjhCuiJy4uThKTtrVy3EFPKNE2x+Y///mPVBdEjqdmWAUbSuEt4fRoLXSnJ1fOEzlPwnXUInpqa2utrm9HosdsNuuauWWLo2PT6gRv3LgRgPN8HsBeVISb6Dl16hSqqqo05fMAnktkFvfKBg0aaA5B0ukhHkEUALQtlS+eroTAULt56xU9jhKZ9cT15Wt/AcDixYudrv2llNMjb5Oa6ImKipIWV3WUzOwN0SOvXO3JvB69oUR5js1TTz0VdDOsvIkYCKqqqqRzS+70aEVPrpy7OU96nB7bBNLCwkJVx7OwsBCVlZVo0KAB2rVrp6tNArVj0+oEi2NyNpgC9iLHV4nMgGPRY1uN2dM0btxYKuYqKlLL2+TofYD7To88n0erGxe2Tk9xcTHGjh2LrKws9O7dG7NmzbJag0bOxo0bMWzYMHTr1g3XXXcd8vPzrV5fsmQJrrrqKnTr1g233367tMI0UD+d8/7770evXr1w+eWX4/HHH/fok7Y/EdWXFy9ejFdffRUA8PHHH2PcuHEAgMsvv1x6ulKagSJHntimJefEUXhLT1w/JyfH7mbhbO0vtZwe4fQ4EiBakpldET2O4ucCb4ged4tMBtsMK2+SmJgozTARg4Fep0fgq36VT1t3hhiAGzdujMjISFRVVdmt0C1wZeaWVrQ6waKURaA7PY5cE287PQaDQfrso0ePahY94vXTp0+7lWOoJYlZEPZOz6RJkxAfH49NmzYhNzcXP/zwA9555x27/QoLCzF+/HhMnDgRW7duxfjx4zFp0iTpZMrLy8OyZcuwdOlSbNmyBZ07d8aECRMka//RRx9Fhw4d8L///Q+ff/45Dh8+bOUsBCvy6ssPPfQQqqqqEB0djaqqKtx6660AgL/++ku6idvWGrFFXAQWi8Vuyq4Szur0eCqurxTq0pLTo4aWZGZvOD3yfTwpejyx5EMwzbDyJhEREVKIS1wDrjg9Al/0qx6nRww2rVu3lgYppRCX2WzGp59+CqD+fuEs3KwXrU6wuFfpdXpiY2M1XY+ewtFMKF+s+C7P69Hr9KhNtdeK1iRmIHCWovCL6Dlw4AAKCgowdepUxMXFIS0tDWPHjsXy5cvt9s3Ly0NWVhYGDRqEqKgoXH/99ejZsydWrlwJAFi1ahXGjBmDjIwMxMbG4rHHHsPhw4exZcsWAMC+ffuk1bEtFgsMBoPqisf+wtF6WUqoJa7W1NTgpptuQmFhIaKionDs2DHpCdCZ0yPq9wDaQlzO6vQAnonrK639pRbe0uL0eFL0HDx4UPOUdfk+nhQ93l7yIdywzetx9rDgb4ToOXHihJ3zaYsYbJo3b44LL7wQgL3oEQ9Tb775JgDgm2++cRpu1otWJ1jcY/Q6Pc2bN/fK9HA11MJbZrNZijocOXLE4+JR4IroadCggfTw6E5ej5ZqzAKRQvHHH39oGue8hV9Ez549e5CcnGx1orZv3x6HDx+2Cz3t3bvXbrXoDh06YNeuXYqvR0dHIz09XXp9/PjxeP/999GtWzf06dMH1dXVmDJlisP2mc1mj/+n9rm5ubmK62Xl5uYq7l9dXa3qkAgef/xxdO3aFQCwefNmmM1m6ebduHFj1TaKC+X48eNOj0f8TomJiU6POzs7G6NHj5YGXlHjRgtFRUV2nyli2BUVFVbbxUDlqE3iZr9t2zb897//RXV1td0+QvSIWje2/7Vq1QoGgwGVlZXYu3cvgPqaPs76TDhQZ86c8eh5NXfuXMW+Ezf+l19+2efndbD+JwZYkVAvrpumTZv6vW1K/Z2YmCiJ6cLCQofvFaGsZs2aSevg7du3T3o9NzfX4SxAtXuSK/+NGDECq1atshss27Rpg1WrVmHEiBFW6/E5+zz5w1dcXJzide1uX6v9J4SyOGdEX6anp0sO3JQpUxze1935T4yjhw8f1tVn4lw/efKky98tHqpbt27tcL/c3Fw88MAD0nlqO8556j6iBe8vQ6tAWVmZndsi/i4vL7c6gZX2bdCggVSAydnrBoMBDz/8MO6++26UlJTg0UcfxVNPPYX/+7//U22fs4q9riKqhQrWr1+Pxx9/3G6/v//+GzfddBNefPFFDBw4EED9CbFt2zYUFBRoqr4skg/Xrl2L9u3bSze84uJibN++XfG9oh+3bt0qPQWoIQRGUVGRS7Z9aWmp5v1s2ysutDNnzli9tm/fPgD1ose2r4H6/n7xxRcB1F/ogwYNQvPmzTFlyhSpn8vKyqS2nThxQnV6ebNmzXD8+HFprR9H/SoQsfM//vjD6b62iN//5MmTSElJQffu3aV+v/DCC/HCCy/gn//8p1VeXPPmzfHYY4/hwgsv1P19elDq62BF9OmOHTvQunVrqzXWvNmHerDt72bNmuHcuXPIz8+X7ntKiHPVYDBI1/dPP/2E7du3w2w2Y9y4cQ7DzY888gguuOACj4XpLrzwQnz88cfYsmULJkyYAKA+P7NZs2bYvn275JKUl5c77Pv169fjpZdekv7evXs30tLSrK5rV9FybosHwEOHDmH79u267uue5LfffpPcbmd9Bljf70UahF7EWFlTU6P6fVr7w1f3Eb+Invj4eDsrVvxtW4QqLi7OLoxRWVkp7efo9V9//RXz58/Hjz/+iKioKMTHx+Pxxx/Hrbfeiqefflo19yMzMxPx8fFuHaMcs9mMnTt3omvXrtINw2w2Y+TIkarvMRgMWLBgASZOnIhPPvkEkydP1rVoZKdOnfDtt9+isLAQXbt2lazivn37SnaoLampqdi1axeSk5OlVcnVjkeIgT59+rgUr+7atStmzpyJoqIixRutwWBAmzZtcPfdd9vdZIV4sFgsVu0UDlBiYqJVXwP1YdJp06bZfdeJEycwbdo0rFq1CqNGjZIu4qSkJKl2kRLt27fH8ePHpfO2S5cuDvsMOB/3btSokdN95eTl5dn9/qmpqZg7dy5GjRoFoH6l7RkzZqC0tBSzZ89GVlYWsrOzvZqfo3ReBztpaWkoKCiQfiNxb+nZs6eu38wbqPV3ZmYm/vrrL8TExDhsoxjYLr74YqSnp+P111/H2bNn0a1bN2zYsMFprsWxY8dw7tw59O/f3xOHI9GjRw/MmTMHBw4cQIMGDaRjENdq165dVY9L63WtFz3ntnADa2pq0LVrV833dU9dM5deeimA+pIE4t54ySWXOD1fW7Vqhb/++gtNmzZ1+dwWD799+/ZV/Ayt41y/fv3QrVs3t/qkvLxck2HhF9GTkZGB06dPS0+tQP1TesuWLe1yIzIzM62WFwDqQ1pdunSRPmvPnj0YMGAAgPoTr7CwEJmZmVIcVZ6dHh0d7bQAnzvrDTlC/rla18uaPXs2nnnmGYfhLCUuv/xyvPHGG/jpp59w6tQp6f3NmzdXPTYRcy0pKXF4/HKXpkmTJi71lYjr5+TkwGAwWB2fCMvMnz/fbgo+cD5RubKy0uq7hbATa4vJBebkyZNVn2INBgMeffRRjBo1Sko8bN26tcPjSk9Pxw8//CD9nZyc7LQfhINZVlamuc9MJhNGjx5t1/aioiKMHj1amgJ96NAhlJaWIioqCpMnT1bsN2/hrevFH4gQ75kzZxAZGSkNaC1atAiYY7Ttb5HX8/fffztsoziWli1bSguIFhYWIjIyUnNy6fHjx73SDx07dsSBAwewd+9eSVQJ16Jp06aK36nnuna1zVrObZEneerUKXz//fea7uvff/+9x8SjyD08duyYJNJTUlKcttv2XNdLbW2tFEFo27at4mdoHee2bduGHj16uHVuaX2vX3J60tPT0aNHDzz33HMoLS3FoUOHsGjRIuTk5NjtO3z4cBQUFGDdunWora3FunXrUFBQIBXbu/HGG/H+++9j165dqKqqwpw5c5CSkoKsrCz06NEDcXFxeO6551BVVYXi4mLMmTMH11xzjd+TmbVONZ4/f74uwSMSV8eMGYOkpCSUl5fj22+/BVA/MAs3RAkhepwltglxERMTg9jYWM1ts8XVtb/Upqyrzd7SkzTtLIlZIJKZBd5IZDabtRceFA8GGRkZPhU8oYZ89lZtba30JOvK7C1foXXaulIi86FDh1BTU+ORWYDuoDTBwFlSrjuTITyJPJHZ3RISruBKIjPgfoHCo0ePoq6uDlFRUapuv9bj9OUipH6bsr5gwQLU1tbi6quvlpJcx44dCwDo3r07PvnkEwD1YYRXX30VixcvRs+ePbFo0SIsXLhQumhzcnJw1113Ydy4cejTpw9+//13LF68GNHR0WjSpAmWLl2KwsJCZGdnY+TIkUhPT8dzzz3nr8OW0Hrz0HNCymc+xMTEICsrCwDw2WefAXB+49ZaoNDZdHU9uFLPRD5lXS4I1GZv6bkRuSp6vFGnR89NXRSndKV6LjmPvGibcEjly7gEIlqnrctFT8uWLREbG4u6ujocOnTI77MAlUSPsxXW/SEwlBDnRkVFhebzxJPiUb7oqCuix9UCheLe1Lp1a9WcIK3H6cvZkX4JbwH1B7lgwQLF17Zt22b1d3Z2turFZjAYcM899+Cee+5RfL1Lly6K9X/8jbjJOMppady4sS7Rk5qainnz5kmCoVevXsjPz8fnn38OwLnoEReKM9GjZbq6HkQ9E60Il66urg61tbWSe6Xm9Oh5iv3xxx8BBIbTo+emLkSPnhWxiT3yKevi6bNx48ZSobxAxBXRExERgfT0dPz555/Yv38/2rVrJ4WbbfHFsiSdOnUCcF70mM1m6SFGbQD3tzslSEpKQkREBOrq6nDxxRc7va+npqZ6VDyK2VvySRdaRI+7K61rKUyoZZxr06YNunfv7lIbXIHLUPgJea0KW8RNRqzE7Ix//etfig5J7969AWivNaI3vOUJp8cV5DPL5CEuNadHz1NsIIW39NzUXV0cklgjX3TUncKEvkQuetRC4eXl5VIunghF2NbqMRqNmD59ut17fbEsiXB6/vrrL9TU1ODMmTPSsag5Pf52pwQRERFSG8+ePev0vu5p8ZiYmGj3oKdl4WZPOT2ORI+Wmkxz5871ab4cRY8fETktto6JuMlMnz5d00X9zDPPKFZ87dWrl9XfgRjecgV5HpFI3KutrZWedGxvAHoWgXS2wrpALnqioqI05TbpFT1ab+p9+/al0+Mh5E5PoBcmFLRp00aqG6WWGyGORV6tWK1AIQBce+21Pl2WpE2bNkhISEBtbS3++usvaSBOSEhQzVHTc117G3lej9FoxJNPPmm3jzfFo3xGrpZJFYD7OT1al6Bwlrvpyuw6d6Do8TNGo9GqZkOXLl2km4y7F3WbNm2sBu/y8nKHBZy0ih5Ph7f0YjAYJJEhRI9oE6C8DIXahdekSROrG5FWpychIUHqr9jYWGzcuNFpcSy9okeLGzhv3jwcPXoUZ8+eRWRkJDIyMjR9NlFG7vQ4q2IeKMTExEjXuVqISx7aEueOkuj53//+B6B+gogvlyUxGAxW6+JpzU1xdTKEp1GryjxkyBCfiEd5oV+teUXuOj2iwKyWasyBtMYfRU8AsGPHDunfdXV1VjcZdy5qk8lkdUJ/8MEHDkvKO1otWI6/nR7AfikKIXoSEhJU8y/kF54ocfDggw9KfWixWDSLHpPJJPVDWVmZVGHUUbl+V5ahEL+/rV3dokUL6fcXLo9YioW4TjA6PYDzvB656BHYip6amhpp+Z4rr7zSa21VQ57M7CyJWU4gDKi2905RzsJoNPpEPMqdHl+JHj2LjQKBs8YfRY+fOX36tNWTlpLgMBqN2L9/v5Qhv3LlSqcXtVify7Zwo6MVzIVzce7cOVRXV6t+tr9zegD7aesin8dZm8SFJ0oe/PHHH9JrZ8+elSraOgpvib6tqamx2u5sdXhX194yGo1SxVrBE088If3+Ip+HoS33kedmCKEQ6E4PUF9UEXAueuTHYit6duzYgfLyciQnJ+Oiiy7yZnMVkYsePbOQAP8PqPJQUW1trSQeHRU49SSuiB5fJDIHIhQ9fka4PGIQLy4uVkxGrKiokIos3nDDDQ4vaj31XeQkJydL1rcjt8ff4S3AfqV10SYtCXwApOKWojQ/cD60lZycrFqR29W+BdxbcFSEHEUl8g0bNkivcbq65xDnj8VikZY1CSanR61WjyOn59ixYygvL5dCW1dccYXLyxK4gxA9u3bt0uX0BAJyAbFz506Ul5ejUaNGPhOP7jg9Yi1APdTV1elaYT2QoOjxM2K9kr59+wKot5iV1nsSg15sbKzTJTJcLdoln4XgKK8nEMNbwunRKsSE6Nm7d6/kFmkJbblTEE2InqqqKjuXyBki1DJ8+HAAwMaNGyURzCRmzxETEyNdX3v27AEQHE6PK+Gtxo0bS9dLYWGhJHr8EdoC3HN6/I08vCVCW3369PGZeHRH9FgsFqucSGeYzWasXr1auoe5sgyRP6Ho8TNC9FxxxRVSPoaSyyJESNOmTVVn8wjcKdqlZdp6IDk9QrDodXqaN2+OlJQUWCwWKcQl+sOR6HGnb+XT2vW6PSKpdsiQIUhKSkJJSQl27NgBi8XC8JaHEYOBCPsEk9OjR/QYDAarEJe/RY9IZD558qTksgWb0yOWogDqlwLyFXJhfvbsWU3OjVzgaw1xmUwmpKen48Ybb5S2ZWRkOMxlDDQoevyMED3du3d3WBxQLnqc4U7RLi0zuALB6bENb2nN6REYDAa7EJcWp8edvo2OjpaErV7RI1836aqrrgJQv3rxkSNHcObMGUREREhPysQ9hHAWA0coOD3i/LF9KheiZ8OGDTh8+DCioqLQs2dPL7ZUncTERClUsnnzZgDB4/TIc3qE0+OrfB6TyYQHHnhA+vv99993OqlCoCeZWeQy2jrdznIZAw2KHj9SXV0tPaXLRY8zp8cZ7hTt0lKVOZASmV3N6QHs83qE6HEkbNwtiOZqXo+8UJ6YeZafny+dPx06dODMLQ9h6y4Ek+g5cuQIqqqq7F5XcnqA86JnxYoVAIDLLrvMafjcmwjhLtzXYHN6du3ahb/++gsGg0EqDutNhBCxXTBWqxDRksxsNpvx3//+F/fff79LuYyBBkWPH/n9999RU1OD5ORkXHDBBQ5DS3pi3O7U9wmW8Ja7OT3A+cRfPU6Pu7WTXBE9FovFqmaMED3ffvstfvnlF6tjIe5jK5yDIbzVtGlT6UHgtddew4YNG6wGIGeiR5z7/gptCWzdymBxekQ7RSJ5ly5dvH5/dGdShcCZ0yPCWYMGDXI4JvhqcVdPQNHjR0Roq1u3blaLGrrr9ACu1/cJtvCWqzk9wHmnR7glWmv0uFM7yRXRI1b8BupFz6WXXorGjRvj3LlzeP/99wEwn8eTyN2FuLg4acZcIJOXlyedI5MnT7aqG2WxWFRFj3CIBH369PFNg1WwFT3B5vQIfJHP44lV5h1VZVYLZznC24u7eoLAXUUvDBALq4rF1jyV0yMwGo0YMWIENm3ahCNHjqBVq1bIzs52ON1dT3grEBKZXc3pAc67IwcPHsTZs2c1ix7Atb4FXBM9IrSVlJQkhbD69euH1atXS8IZqH/y81fBr1BCLpyDweURg5PtE78Icbz77rvSTBt5qM5kMmHs2LFW75k0aRKioqL8UikXCF6nx/a+44vQlidWmVdzehy5SI7w9uKunoBOjx+ROz2A44rIrogeQH/RLmfhraqqKqlwYSBNWXfF6WncuLHk1vz666+6RA/gWkE0d0SPfMCyHQxmzZqlOXmROEbuLgR6Po+WEMfjjz8OoP4hRTwsCKF07Ngxq/ccPXrUr0mpwej0mEwmu+Tv6dOne70PPbHKvLhffv/991YhUWcuki2+WtzVE1D0+AmLxWInehwJDldFj16chbfk9Ry0rCzuLdQqMut1n0SI67vvvpMSQL35tOIJ0WMymfD222/b7RdssygClWByerSEOI4ePQrgfGjLE7kg3uKCCy6wSsj//fffAzo5VohHUahPcOzYMa9fi+5OqjCZTHjrrbcAAGvXrrUKieoJU/l6cVd3oejxE4WFhTh79ixiYmKkqp2eDm+5grPwlhA9SUlJfqnaKvDE7C3gfIjrq6++AlDfv96cBeWO6ElJSQnoAStUCCanR8/gJESPJ3JBvMXq1aulopsAMGzYsIB1MP19LbozqUKINZGfKRAPTqIwpxZ8vbiru1D0+AmRz9OlSxdER0cDcBze8lWFUmfhrUBIYgY8k9MDnHd6xA3e2zFpd52eQB6wQgW56Al0p0fP+SpEjydyQbyBq2va+YtAuBZdmVShRawtWbLEoYsE1I9F33zzjd9WS3cVih4/IMp4A/WrZYsnAW/k9OhFHt5SuigCoUYPYJ3TIy+jrtfpEaJH5ClpzedxFXdFT6AOWKGEbeXsQHbNtIQ4RMhXiB5P5IJ4Gn+7Jq4QKNei3lXmtYi1v//+G/fff7/i6waDAQaDAUuWLMHVV18dFCEtORQ9XsZsNmPDhg344osvsGHDBuTm5iI9PR3Lli0DAHz++eeSfavmstTW1kpOhq/CW1VVVdKK43KE0+PPmVuAdU5PeXm5NF1Xrxizneod6KInEAesUMJkMmHMmDHS32+99VbAhlcAbSEOURlYiB53c0G8QSC4JnoJpGtRz6QKrSIsIyMD7733nt32YAtn2ULR40XkhZ3+9a9/YdCgQbjppptUy3hv2bIFgL3LIp9O6O3wVmJiohRuU3KcAsXpkYe3RJsiIyN111RJSEiQCrQB9Qu+evNp0l3RE4gDVqigNqMpUMMrAmchDnHOifwkdwtseoNAcU30EKzXoh6xlp6eDqD+3NHiIgUDFD1eQk9hJyFwnn32WQD2K62L0FajRo0QFeXd0koGg8HhDK5AqNEDWIe35Pk8zhZjtcV2psLy5cu9+mTvrugJxAErFAjG8IocEeL44IMPAAARERHYuXMnjEajYmFCdwpseoNAck20EqzXoh6xJmYY9+7dW1dpjkCGoscLuFLYScRRhaiRuyy+SmIWOJrBFWiJzBUVFS7n8whhKpKhBd58svfElPVAG7BCgWAMr9gSGRmJm2++Genp6airq5MW7VSrxqw3F8SbBKtrEozXoh6xZltWJRSg6PECegs7yUlMTARgLTh8lcQs0OL0BIrosXV6tOKvJ3u9osdisSgWJwykASsUCMbwihr9+/cHAGzcuBGA+grrgGsFNr1BsLomQHBei1rF2o4dOwBQ9BAnuHNjFG6F3Onxl+hxlNMTSOEtV5wefz3Z6xU9ZWVlUtFE25oxgTJghQLBGF5Ro1+/fgCADRs2oLa2Vrp/KImeQCIYXRNBMF6LQqytWbNG2lZQUCD1c21tLXbu3AkAuPTSS/3SRm9A0eMFXLkxCvs2NTUVQGCInmAIb7nq9PjryV6v6BFP6Q0aNAiKhS+DlWANryghnJ4ff/wRBw8ehMViscrVC2SC0TUJZiIjIzF8+HBpFquYTAMAf/75J6qqqpCYmIh27dr5q4keh6LHCzi7gdoit29FMTR/ih5HOT2BFt5yNafHX0/2ctGjJedLHtrSm6RNtBPM4RVb0tPT0bZtW9TW1kr1wFJSUoKi7UBwuibBzpVXXgmgfjkegQhtXXrppX6tvu9pQudIAghHN1Al5PatkuAQAigQwluBVqfHVafHX0/2QvSYzWa7BGollPJ5iHcI5vCKLSLEtWrVKgCBH9oi/qVv374AgP/973/SNpHEHEqhLYCix2uo3UDT0tKwatUqVftWqSqzEEC+mr0VDInM7ub0+OvJXiSqA9pCXBQ9viVUwisixCXCFRQ9xBHC6dm6dau0iHMoztwCAO8WfQlzjEYjRowYgQ0bNmDz5s3o06ePU7vWkegJpPBWoDg9FRUVLq+7JYTpxIkTrZKaU1NTMW/ePK8MdBaLBQ0aNEBlZSW+/vpr3HzzzQ7PB4oe3yPCK8GMcHrkmM1mhoqIIu3atUOLFi1w7NgxbN26FX379g1Z0UOnx8uIG+iQIUM0xaeVXJZAmr0VyInMeuv0AL59shcVukVY67bbbnNaCJGih7jCtm3brO41+fn5Ab2cBvEvBoPBKsR19OhRnDhxAhEREdL6hKECRU+AEQhOj1p4q66uTgrJ+Fv0iPCWvI6Nq23yReKkWoVuZ4UQKXqIXkwmE2666Sa7GlOBvpwG8S/yZGbh8nTs2FG614YKFD0BhpLo8XUis7wNdXV10vbS0lJpxlGghLcASGslueL0+AJ3CiFS9BA9BPtyGsR/CKfn+++/x7Zt2wCEXmgLoOgJOGxFT0VFhZRY5utE5rq6OimcBZzP54mJibESHf4gJiZG+vfRo0cB+N99UsOdQohC9IhSBoQ4IhSW0yD+oVu3boiPj0dJSQk+/PBDAKE3cwug6Ak45KEli8UihZiioqJ85q7ExsZKhfDkIa5ASWIG6mPQQnjV1NQACFynx51CiHR6iB5CaTkN4luio6PRq1cvAJAqMXft2tWfTfIKFD0BhnBzxErr8unqvixOpzSDK1CSmAW2seZAaZct7hRCpOghegil5TSIbzGZTPjpp5+stt13330hlwNG0RNgxMfHS6GbU6dO+TyJWaCUzBwoNXoEtiG2QGmXLa4WQqysrERpaSkAih6ijVBaToP4DjHRwrZ22NGjR0Mu+Z2iJ8CQr5FTXFzs8yRmgdK09UCpxiyQi574+HhER0f7sTXqOKvQbbFYcN9992HVqlXYsGGDlGQqXJ6oqKiADd2RwCKUltMgviHckt8pegIQeTKzv5wepfBWoDk98vBWoIsCtQrdgqeffhpjxozBgAEDpHoq8iRmrrtFtBJKy2kQ7xNuye+syByAKIkeX83cEjRu3BgAsHHjRlxyySW44oor8PPPPwOon1EWCNVd5U5PoIse4HyF7k2bNuHIkSPYs2cPnn76abv9RD2Vf/3rXwAY2iL6sT3XWrVqhezsbL9fsyTwCLfkd4qeAMTfTo/JZMIHH3wg/dtkMiEyMlKyN7/66iukp6dj/vz5fn1qlIueQHGfnCEKIZrNZqSnpyvuY7FYYDAY8OqrrwKg6CGuEQrLaRDvE27J7wxvBSDynB5fix61hLZArO4abE6PHC2WssinoughhHiLcEt+p+gJQOROjy8TmR0ltNkSCAlu8pyeYHF6BHqsYooeQoi3CLfkd4qeAMRf4S1n7oMt/k5wC2anR49VTNFDCPEm4ZT8zpyeAEQ+c8qXicyuJqr5K8EtGHN6BMJSLioqUnTWRMXpiooKih5CiNcJl+R3ip4ARF4jx5dOj6uJav5KcAumKeu2CEs5JycHBoNBUfi0bdsWu3btoughhPiEcEh+Z3grABGuzsmTJ32a0+Msoc0Wfye4BbPTA6hbyklJScjNzZVWuKfoIYQQz0DRE4AI0VNYWCgNfL4QPc4qB8sJhAS3YM7pERiNRhQWFiI/Px+TJk0CUP9bjxo1iutuEUKIh6HoCUCEwKmsrAQAJCQkIDY21iffreY+2AqbQEhwC3anRyAs5ZkzZyIuLg6FhYX46aefUFJSAoCihxBCPAVzegIQ26RlXy9BoZTQdsUVV+D7778PqAS3YM7pUSIhIQFDhgxBXl4elixZAqDeUfN1NW5CCAlVKHoCELHSenV1NQDfL0EBKCe0BVqCW6g4PXJGjRqFvLw8rFixAkD9b+9vcUkIIaECw1sBiO3Tva+dnmAhJiZG+vfvv/8eEqsADx06FJGRkSgtLQVQL4BD4bgIISQQoOgJUORCh6LHHpPJhKeeekr6e/To0UhPT0deXp4fW+U++fn5iIo6b8AeOnRIWnWdEEKIe1D0BCh0etQR64OJRF9BUVERRo8ejfXr1/upZe4hjquqqspqeyCsc0YIIaEARU+AQtGjjKP1wcS2OXPmBF1ISMtx+XOdM0IICQUoegIUih5ltKxOfuzYMb+tB+YqWo7Ln+ucEUJIKEDRE6DIhQ6nLJ9H6zpfR48e9XJLPIvW4/LXOmeEEBIKUPQEKPK6M0VFRQxr/H+0rvPVsmVLL7fEs2g9Ln+tc0YIIaEARU8AYjKZ8NJLL0l///Of/+QMnv+Ps/XBDAYDWrRo4bf1wFxFy3H5c50zQggJBSh6Agwxg+f06dNW2zmDpx5H64OJvx977LGgK+in5bj8uc4ZIYSEAhQ9AQRn8GhDbX2w1NRUrFq1CgMHDvRTy9zD0XH5e50zQggJBbgMRQChZwZPoC0J4WuU1gcToZ/t27f7t3FuoHZcdHgIIcR9KHoCCM7g0YfS+mCh4IIpHRchhBD3YXgrgOAMHkIIIcR7UPQEEJzBQwghhHgPv4me4uJijB07FllZWejduzdmzZqF2tpaxX03btyIYcOGoVu3brjuuuuQn59v9fqSJUtw1VVXoVu3brj99tvx119/Sa9VVVVh5syZuPLKK9GjRw/ceeed2Ldvn1ePzVU4g4cQQgjxHn4TPZMmTUJ8fDw2bdqE3Nxc/PDDD3jnnXfs9issLMT48eMxceJEbN26FePHj8ekSZNw7NgxAEBeXh6WLVuGpUuXYsuWLejcuTMmTJggzXZ65pln8NtvvyEvLw8//PAD2rdvj4kTJ/ryUHXBGTyEEEKId/CL6Dlw4AAKCgowdepUxMXFIS0tDWPHjsXy5cvt9s3Ly0NWVhYGDRqEqKgoXH/99ejZsydWrlwJAFi1ahXGjBmDjIwMxMbG4rHHHsPhw4exZcsWFBcXY82aNXj++efRvHlzxMTEYMqUKXjhhRcUp4UHCkajEYWFhcjPz8eKFSuQn5+P/fv3U/AQQgghbuCX2Vt79uxBcnIyWrRoIW1r3749Dh8+jLNnz6Jhw4bS9r179yIzM9Pq/R06dMCuXbuk1++//37ptejoaKSnp2PXrl2oqqpCUlIStm/fjnHjxuHUqVPo0aMH/vnPf6rmzQD1M4A8OQtIfJbez7TN3QmFmUnextW+JvphX/sW9rfvYF/7Dk/1tdb3+0X0lJWVIS4uzmqb+Lu8vNxK9Cjt26BBA5SXlzt9/cyZMzh37hy++uorLFu2DNHR0ZgxYwYeeugh5OXlqebG7N692+1jVGLnzp1e+VxiD/vad7CvfQv723ewr32Hr/raL6InPj4eFRUVVtvE3wkJCVbb4+LiUFlZabWtsrJS2s/R6zExMTCbzZg2bZq0UvmTTz6Jyy+/HPv370eHDh0U25eZmYn4+HjXD9AGs9mMnTt3omvXrkxC9jLsa9/BvvYt7G/fwb72HZ7q6/Lyck2GhV9ET0ZGBk6fPo2TJ08iJSUFALBv3z60bNkSSUlJVvtmZmbit99+s9q2d+9edOnSRfqsPXv2YMCAAQCAmpoaFBYWIjMzE82aNQMAVFdXS+8VFpijnJ7IyEivnOje+lxiD/vad7CvfQv723ewr32Hu32t9b1+SWROT09Hjx498Nxzz6G0tBSHDh3CokWLkJOTY7fv8OHDUVBQgHXr1qG2thbr1q1DQUEBRowYAQC48cYb8f7770s5PHPmzEFKSgqysrLQoUMH9OzZE0899RROnTqFsrIyzJ49G507d0ZGRoavD5sQQgghfsRvU9YXLFiA2tpaXH311Rg9ejSys7MxduxYAED37t3xySefAKhPcH711VexePFi9OzZE4sWLcLChQtx4YUXAgBycnJw1113Ydy4cejTpw9+//13LF68GNHR0QCA1157DRkZGRg5ciSys7NRXl6ORYsW+eegCSGEEOI3/Lb2VkpKChYsWKD42rZt26z+zs7OVq1CbDAYcM899+Cee+5RfD0pKQkzZsxwr7GEEEIICXq4DAUhhBBCwgKKHkIIIYSEBRQ9hBBCCAkLKHoIIYQQEhZQ9BBCCCEkLKDoIYQQQkhYQNFDCCGEkLCAoocQQgghYQFFDyGEEELCAooeQgghhIQFFD2EEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCCCFhAUUPIYQQQsICih5CCCGEhAUUPYQQQggJCyh6CCGEEBIWUPQQQgghJCyg6CGEEEJIWEDRQwghhJCwgKKHEEIIIWEBRQ8hhBBCwgKKHkIIIYSEBRQ9hBBCCAkLKHoIIYQQEhZQ9BBCCCEkLKDoIYQQQkhYEOXvBgQSdXV1AICKigqPfq7ZbAYAlJeXIzIy0qOfTaxhX/sO9rVvYX/7Dva17/BUX4txW4zjahgsFovF5W8JMYqLi1FYWOjvZhBCCCHEBdLT09G0aVPV1yl6ZNTW1uLMmTOIjY1FRAQjf4QQQkgwUFdXh6qqKjRq1AhRUepBLIoeQgghhIQFtDMIIYQQEhZQ9BBCCCEkLKDo8TLFxcUYO3YssrKy0Lt3b8yaNQu1tbX+blZIsGvXLtx9993o1asXrrzySjz++OM4deoUAGDHjh246aab0L17dwwcOBAfffSRn1sbGpjNZtx+++144oknpG3sa89y+vRpPP744+jduzd69uyJsWPH4vjx4wDY157mt99+w6233oqsrCz07dsXM2fORHV1NQD2tSc5deoUrrnmGmzZskXa5qx/8/LycM0116Bbt24wGo3Ytm2bZxpjIV7ltttuszz22GOW8vJyy8GDBy033HCDZcmSJf5uVtBTUVFhufLKKy3z58+3VFVVWU6dOmW5//77LQ8++KDl9OnTll69elnef/99S01NjeX777+3dO/e3bJjxw5/NzvomTdvnqVTp06WadOmWSwWC/vaC9x2222WcePGWc6cOWM5d+6c5ZFHHrE88MAD7GsPYzabLVdeeaXl3XfftZjNZsuRI0csgwcPtrzyyivsaw+ydetWy6BBgyyZmZmWzZs3WywW5/eNzZs3W7p3727ZunWrpbq62vL2229bevfubSkvL3e7PXR6vMiBAwdQUFCAqVOnIi4uDmlpaRg7diyWL1/u76YFPYcPH0anTp0wbtw4xMTEoHHjxvjHP/6BH3/8EV999RWSk5Nx6623IioqCpdffjmGDRvGfneTH374AV999RWuvfZaaRv72rP8+uuv2LFjB2bPno2GDRsiMTERzz77LKZMmcK+9jBnzpzBiRMnUFdXB8v/n88TERGBuLg49rWHyMvLw5QpUzB58mSr7c7696OPPsINN9yAHj16IDo6GnfddRcaN26MdevWud0mih4vsmfPHiQnJ6NFixbStvbt2+Pw4cM4e/asH1sW/LRr1w5vvvmmVTGrL7/8Ep07d8aePXuQmZlptX+HDh2wa9cuXzczZCguLsb06dMxZ84cxMXFSdvZ157ll19+QYcOHbBq1Spcc8016Nu3L1544QU0a9aMfe1hGjdujLvuugsvvPACunbtin79+iE9PR133XUX+9pD9O3bF19//TWuv/56q+3O+nfv3r1e63+KHi9SVlZmNUAAkP4uLy/3R5NCEovFgrlz5yI/Px/Tp09X7PcGDRqwz12krq4OU6dOxd13341OnTpZvca+9ixnzpzBn3/+icLCQuTl5WH16tU4duwYpk2bxr72MHV1dWjQoAH+/e9/Y/v27Vi7di327duHBQsWsK89RLNmzRRr5jjrX2/2P0WPF4mPj7db0kL8nZCQ4I8mhRylpaWYMGECPv30U7z//vvo2LEj4uLiUFlZabVfZWUl+9xFFi9ejJiYGNx+++12r7GvPUtMTAwAYPr06UhMTERKSgomTZqEjRs3wmKxsK89yNdff40vv/wSY8aMQUxMDDIyMjBu3Dh88MEHPK+9jLP+9Wb/U/R4kYyMDJw+fRonT56Utu3btw8tW7ZEUlKSH1sWGhw8eBA33ngjSktLkZubi44dOwIAMjMzsWfPHqt99+7di4yMDH80M+hZs2YNCgoKkJWVhaysLKxduxZr165FVlYW+9rDdOjQAXV1daipqZG2ibWELrroIva1Bzly5Ig0U0sQFRWF6Ohontdexln/ZmRkeK3/KXq8SHp6Onr06IHnnnsOpaWlOHToEBYtWoScnBx/Ny3oOXPmDO68805cdtllWLp0KZo0aSK9ds011+DkyZN45513UFNTg82bN+PTTz/FjTfe6McWBy9ffPEFfv75Z2zduhVbt27F0KFDMXToUGzdupV97WGuuOIKpKWl4Z///CfKyspw6tQpzJ07F4MGDcLQoUPZ1x6kb9++OHHiBF5//XWYzWYcOnQIr732GoYNG8bz2ss469+cnBx8+umn2Lx5M2pqavDOO++guLgY11xzjdvfzWUovMzJkycxY8YMbNmyBRERERg5ciSmTJnClXvd5O2338bs2bMRFxcHg8Fg9dq2bduwc+dOzJo1C7t370aTJk0wduxYGI1GP7U2tBA1embPng0A7GsPc+zYMcyePRs//vgjqqqqMHDgQEyfPh0NGzZkX3uY77//HvPmzcNff/2FpKQkDB8+XJoRyr72LB07dsR7772H3r17A3B+31izZg1ee+01HDt2DB06dMC//vUvXHrppW63g6KHEEIIIWEBw1uEEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCCCFhAUUPIYQQQsICih5CCCGEhAUUPYQQQggJCyh6CCEhy2effYYuXbpg165dAIDff/8dl1xyCb799ls/t4wQ4g+4DAUhJKR58skn8dtvv2HZsmUYPXo0Bg8ejEcffdTfzSKE+AGKHkJISFNeXg6j0Yjq6mq0bt0a7777Lhf8JSRMYXiLEBLSxMfH48Ybb0RRURFGjRpFwUNIGEOnhxAS0hw8eBAjR47E9ddfj6+//hpr1qxBy5Yt/d0sQogfoOghhIQsNTU1uOWWW3DRRRfh2WefxSOPPIIzZ87g3XffRUQEjW5Cwg1e9YSQkGX+/PkoKSnBE088AQCYMWMG9u7di8WLF/u5ZYQQf0CnhxBCCCFhAZ0eQgghhIQFFD2EEEIICQsoegghhBASFlD0EEIIISQsoOghhBBCSFhA0UMIIYSQsICihxBCCCFhAUUPIYQQQsICih5CCCGEhAUUPYQQQggJCyh6CCGEEBIWUPQQQgghJCz4fwE7Y3gVaIjVAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<Figure size 640x480 with 1 Axes>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "#画出散点图\n",
    "fig = plt.figure()        \n",
    "ax = plt.axes()\n",
    "x = np.arange(0, 100)\n",
    "y = cross_entropy_y\n",
    "plt.plot(x, y, '-ok')\n",
    "#设置y轴的上下限\n",
    "plt.ylim(0.005, 0.015)\n",
    "plt.title(\"Cross Entropy\") \n",
    "plt.xlabel(\"x\") \n",
    "plt.ylabel(\"cross entropy y\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 17,
   "id": "8d7025db-a281-4b1d-9c07-99fe49c5b438",
   "metadata": {},
   "outputs": [],
   "source": [
    "#保存散点图图片\n",
    "fig.savefig('cross entropy.png')"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.9.13"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
