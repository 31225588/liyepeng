# **库和数据的导入**

```python
#导入numpy、pandas、matplotlib库
#设置图表风格
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
plt.style.use('seaborn-whitegrid')
```







# **数据预处理——x集的分割**     

```python
train_ = pd.read_csv(r"train.csv")
train_ = np.array(train_)
train_x = train_[::,2:786]
#给train_x集左边加上一列全1列，是为了后面与theta矩阵相乘多出一个偏移项。
train_x = np.hstack([np.ones((20000,1)),train_x])
#对train_x/1024是为了后面取以e为底的指数时，结果不至于数据溢出.
train_x = train_x / 1024
```







# **数据预处理——y值的独热编码**   
----

- ## **独热编码的原理：**

1. **在独热编码中，每个样本都只有一个特征值等于1，其他特征值均为0，这代表该样本属于对应的类别。**    


-----
- ## **独热编码遇到的问题：**    

1. **想要直接直接把[1,0,0,0,0,0,0,0,0,0]赋值给1，但是1是个数，不好赋值。**     

----
- ## **独热编码问题的解决：**    

1. **使用花式索引将label列作为花式索引的其中一个轴。**

```python
#先分割出y训练集
train_y0 = train_[::,1:2]
#再将y训练集转置，作为后面独热编码进行的花式索引的其中一个轴。
train_y1 = train_y0.T

#先创建一个全0数组，然后将数组m和数组train_y0作为全0数组花式索引的xy轴。
#例:m第一个元素取0时，trian_y0第一个元素取0，就表示第一个样本属于第0类，
#在全0数组的花式索引中就表示将第一行第一列的那个元素取出。
#再将取出的元素都加上1，那么样本1的label的独热编码就为[1,0,0,0,0,0,0,0,0,0]
y = np.zeros((20000,10))
m = np.arange(0,20000).reshape(1,20000)
y[m,train_y1] += 1
train_y = y
```







# **定义softmax函数**    
---

- ## **softmax函数原理：** 

$$
softmax(x{^i_j})
= \frac{exp(x{^i_j})}{\sum\limits_{j=1}^k exp(x{^i_j})}
$$

$$
\hline
	符号                          &       符号说明         \\
 \hline
	     x{^i_j}               &   第i个样本的第j个元素    \\      
	    i                    &   第i个样本        \\      
	    j                    &   第j类        \\      
	    k                    &   类型总数        \\
	   m                         &           训练集总样本数 \\
\hline
$$

- ## **定义softmax函数遇到的问题：**    

1. **调用softmax函数时会显示np.exp(x)数据溢出。**     

----
- ## **定义softmax函数问题的解决：**

1. **数据溢出的原因是因为x训练集的数值太大，再取以e为底的指数时就会数据溢出，所以要对x训练集中的每一个数据/1024，这样数值不至于溢出。**

```python
def softmax(X):
    #先对分割出的x集取以e为底的指数
    X_exp = np.exp(X)
    #在进行按行求和
    sum_ = X_exp.sum(1).reshape(len(X),1)
    #利用广播机制，让X_exp中的每一个元素都除之前的行求和结果。
    #得出的结果是每一个样本是第x类的概率。
    return X_exp / sum_
```









# **定义带有岭回归正则化项softmax回归梯度下降函数**    

- ## **带有岭回归正则化项softmax回归梯度下降函数公式：**

$$
\theta{^{(t+1)} _j  } 
= \theta{^{(t)} _j  }
- \frac{\eta}{m}\sum\limits_{i=1}^m
\frac{y{^{(i)}_j}}
{h{_\theta}(x^{(i)}){_j}}
(1-h{_\theta}x^{(i)}){_j})
x^{(i)}- 2 \lambda \theta{^{(t)} _j  }
$$

$$
\hline
	符号                          &       符号说明         \\
 \hline
	    \theta{^{(t+1)} _j  }    & 第j个类别迭代后的权重系数            \\
	   \theta{^{(t)} _j  }       & 第j个类别迭代前的权重系数             \\
	   \eta                      &   学习率（步长）         \\
	   \lambda                      &   岭系数         \\       
	    y{^{(i)}_j}                     &   第i个样本是否属于第j个样本         \\       
	    h{_\theta}(x^{(i)}){_j}                 &   第i个样本属于第j个类别的概率     \\
	  \theta_j                    &   第j个类别的预测概率         \\
	    i                    &   第i个样本        \\      
	    j                    &   第j个类别        \\      
	    k                    &   类别总数        \\
	   m                         &           训练集总样本数 \\
\hline
$$

- ## 带有岭回归正则化项**softmax回归梯度下降原理：**    

1. **与线性回归根本目的相同，梯度下降根本目的都是使得最后的预测值与真实值之间的误差尽量最小。**     
2. **这里衡量误差的模型是交叉熵损失函数，所以就等同于使交叉熵损失最小。**
3. **因为交叉熵损失函数对预测概率取对数，又因为概率在0-1之间，所以要在对数前叫一个负号，使函数值恒为正，并且预测概率越接近1，交叉熵损失越小。**     

----

- ## **带有岭回归正则化项softmax回归梯度下降求偏导具体推导：**

$$
J(\theta) 
= -\sum\limits_{i=1}^m \sum\limits_{j=1}^k y{_j^{(i)}}log(h_ \theta(x^{(i)})_j))
$$

$$
\begin{aligned}
\frac{\partial J(\theta) }{\partial \theta_j}
&=
-\frac{1}{m} \sum\limits_{i=1}^m
\frac{\partial(y{_j^{(i)}}log(h_ \theta(x^{(i)})_j)} {\partial\theta_i}\\
&=
-\frac{1}{m} \sum\limits_{i=1}^m
\frac{y{^{(i)}_j}}
{h{_\theta}(x^{(i)}){_j}}
\frac{\partial h_ \theta(x^{(i)})_j)}
{\partial\theta_i}\\
&=
- \frac{1}{m}\sum\limits_{i=1}^m
\frac{y{^{(i)}_j}}
{h{_\theta}(x^{(i)}){_j}}
(1-h{_\theta}x^{(i)}){_j})
x^{(i)}
\end{aligned}
$$



- ## **定义带有岭回归正则化项softmax回归梯度下降函数遇到的问题：**      

1. **最终画出交叉熵损失变化情况的散点图时，发现结果并不像线性回归方程的loss函数一样会收敛，而是再一条水平直线附近震荡，直接确定迭代次数就不一定是取到一个局部最优解，会错过一些交叉熵损失更低的点。**     

----



- ## **定义带有岭回归正则化项softmax回归梯度下降函数问题的解决：**     

1. **给迭代次数增加一个限制，当迭代出的theta值对应的交叉熵损失小于设置的阈值，那么此时迭代停止，就能取到一个局部最优解，阈值的确定依靠打印出的交叉熵损失函数。**

```python
def gradient_descent(X,y,theta,eta,n,lamda,eplison):
    a = 0
    while a<n:
        #梯度下降
        y_hat = softmax(np.dot(X,theta))
        dj = np.dot(X.T,y_hat - y)
        theta = theta - eta*dj - 2*theta*lamda
        #以交叉熵损失作为限制条件，当最终的theta对应的交叉熵损失小于设置的eplison时，迭代停止。
        y_hat1 = y_hat.max(axis=1)
        cross_entropy = np.sum((-np.log(y_hat1)),axis = 0)
        if cross_entropy < eplison:
            break
        a = a+1
    return theta
```







# **目标测试集y值的预测** #

```python
#得出最终的权重矩阵。
#eta lamda 等参数大小由后面打印出的交叉熵损失确定
theta = np.zeros((785,10))
eta = 0.031
n = 1e4
lamda = 0.0001
eplison  = 0.005
theta_result = gradient_descent(train_x, train_y,theta,eta,n,lamda,eplison)
```

```python
#导入测试数据集
test_ = pd.read_csv(r"test_no_answer.csv")
test_ = np.array(test_)
```

```python
#测试集x值的分割
test_x = test_[::,1:785]
test_x = np.hstack([np.ones((2000,1)),test_x])
#对x集同样/1024，同样是为了防止数据溢出。
test_x = test_x / 1024
```

```python
#得出每个测试集样本的分类
predict_test_y = np.dot(test_x,theta_result)
predict_test_y = softmax(predict_test_y)
#返回每个样本是某个label概率的最大值的索引，即为这个样本的label
result_ = predict_test_y.argmax(axis=1)
```

```python
#数据的导出
result_ = result_.reshape(2000,1)
result_ = np.hstack([np.arange(1,2001).reshape(2000,1),result_])
result_ = pd.DataFrame(result_, columns=['id', 'label'])
result_.to_csv('result_test.csv')
```







# **模型评估——accuracy函数** #

```python
#用训练集的x值预测y值，将预测的值与真实值对比，计算出预测正确的值占总样本数的占比。
predict_train_y = np.dot(train_x,theta_result)
predict_train_y = softmax(predict_train_y)
result_ = predict_train_y.argmax(axis=1)
result_ = result_.reshape(20000,1)
```

```python
#accurcy函数
#将预测值与真实值相减，如果预测值和真实值相同，那么就为0，如果不相同，就不为0.
#将相减之后的数组与全0数组比较，得出一个布尔值的数组，相等为1，不相等为0
#求和的结果就是预测值和真实值相等的样本个数
#再将相等个数除以总数就是accurcy
def accurcy(y,y1):
    a = y - y1
    return np.sum(a == np.zeros((20000,1)) ) / len(y)
```

```python
#计算accuracy
accurcy(result_,train_y0)
```







# **模型评估——交叉熵损失变化情况的可视化** #     


- ## **交叉熵损失函数公式：**


$$
J(\theta) 
= -\sum\limits_{i=1}^m \sum\limits_{j=1}^k y{_j^{(i)}}log(h_ \theta(x^{(i)})_j))
$$

$$
\hline
	符号                          &       符号说明         \\
 \hline
	   x{_j^{(i)}}                  &   第i个样本的真实标签是否属于第j类    \\
	   h_ \theta(x^{(i)})_j                  &  第i个样本属于第j类的概率         \\       
	    i                    &   第i个样本        \\      
	    j                    &   第j类        \\      
	    k                    &   类别总数        \\
	   m                         &           训练集总样本数 \\
\hline
$$

- ## **模型评估——交叉熵损失变化情况的可视化遇到的问题：**

1. **一开始交叉熵下降的很快，导致图像都缩在一团。**    

----
- ## **模型评估——交叉熵损失变化情况的可视化问题的解决：**

1. **因为交叉熵损失一开始很大，所以导致计算机自动选取的y轴单位值太大，等到后面交叉熵损失变小，就会导致图像缩在一起。**     
2. **避开前面交叉熵损失较大的点就可以解决问题。**

```python
#利用每一次梯度下降迭代出的theta，计算每一个theta对应的平均交叉熵损失，放入cross_entropy_y
#作为散点图的y坐标
def cross_entropy(X,y,theta,eta,n,lamda,eplison):
    a = 0
    cross_entropy_y = []
    while a<n:
        y_hat = softmax(np.dot(X,theta))
        dj = np.dot(X.T,y_hat - y)
        theta = theta - eta*dj - 2*lamda*theta
        y_hat1 = y_hat.max(axis=1)
        cross_entropy = np.sum((-np.log(y_hat1)),axis = 0) 
        cross_entropy = cross_entropy / len(y)
        cross_entropy_y.append(cross_entropy)
        if cross_entropy < eplison:
            break
        a = a+1
    return cross_entropy_y
```

```python
#得出散点图各个点的y值
theta = np.zeros((785,10))
eta = 0.031
n = 1e4
lamda = 0.0001
eplison  = 0.005
cross_entropy_y = cross_entropy(train_x, train_y,theta,eta,n,lamda,eplison)
#以90为步长取100个点
cross_entropy_y = cross_entropy_y[1000:10000:90]
```

```python
#画出散点图
fig = plt.figure()        
ax = plt.axes()
x = np.arange(0, 100)
y = cross_entropy_y
plt.plot(x, y, '-ok')
#设置y轴的上下限
plt.ylim(0.005, 0.015)
plt.title("Cross Entropy") 
plt.xlabel("x") 
plt.ylabel("cross entropy y")
```

![cross entropy](C:\Users\liyepeng\Downloads\cross entropy.png)

```python
#保存散点图图片
fig.savefig('cross entropy.png')
```

